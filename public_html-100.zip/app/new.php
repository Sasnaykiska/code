<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel = "icon" href = "logo2.png" type = "image/x-icon">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="style.css">
    <script src="../wave.js"></script>
    <title>Waves</title>
    <style>
    h1{
        color: black;
        font-size: 25px;
    }
    h3{
        color: black;
        font-size: 20px;
    }


    </style>
</head>
<body>
    <div class="sidebar" style="left: -250px;">
        <a href="#">
        <img src="logo2.png" style="height: 40px; width: 40px;"/>
        </a>
        <div class="side-nav">
            <div class="item">
                <i class='bx bx-search-alt' ></i>
                <a href="#">Home</a>
            </div>
            <div class="item">
                <i class='bx bx-message-square-dots'></i>
                <a href="#">Playlists</a>
            </div>
            <div class="item">
                <i class='bx bx-briefcase'></i>
                <a href="#">Upload</a>
            </div>
            <div class="item">
                <i class='bx bx-bookmark-minus'></i>
                <a href="#">Favorites</a>
            </div>
            <div class="item">
                <i class='bx bx-cog'></i>
                <a href="#">Log Out</a>
            </div>
        </div>
        <div class="side-profile" style="visibility: hidden;">
            <div class="info">
                <img src="assets/profile-1.png">
                <a href="#">Alex.Talent</a>
                <p>Graphic Designer</p>
            </div>
            <div class="skills">
                <h5>Skills and Expertise</h5>
                <div class="skill-tags">
                    <div class="item">
                        <p>Graphic Designer</p>
                    </div>
                    <div class="item">
                        <p>Illustrator</p>
                    </div>
                    <div class="item">
                        <p>Photoshop</p>
                    </div>
                    <div class="item">
                        <p>HTML/CSS</p>
                    </div>
                </div>
            </div>
            <button>View Profile</button>
        </div>

    </div>
    <div class="container">
        <div class="nav">
            <button id="menuToggle"><i class='bx bx-menu'></i></button>
            <div class="search">
                <i class='bx bx-search'></i>
                <input type="text" placeholder="Search for jobs or companies">
            </div>
            <button>Search</button>
            <div class="user-info">
                <img src="assets/profile-1.png">
                <div class="user-name">
                    <a href="#" class="user-name">Reza.UI</a>
                </div>
            </div>
        </div>
        <div class="main">
            <div class="content">
            <div class="header">
                    <h4>Popular Playlists</h4>
                </div>    
            
            
                <br>
    <div class="d-flex justify-content-between" style="" id="ge">
    <div class="col results" id="co">  
    <a href='http://soniasonec.temp.swtest.ru/playlist/edm.php'>
            <div class="image" data-tilt data-tile-genre>
              <img class="genre" src="50.png" width="300px" height="300px">
              <h1 style="color: white" class="bottom-left"></h1>
			</div>
	</a>
    
    
    
    
    <?php
    if(!empty($_COOKIE["login"])){
        echo '
        
            <a href="http://soniasonec.temp.swtest.ru/playlist/favorites.php">
            <div class="image" data-tilt data-tile-genre>
              <img class="genre" src="http://soniasonec.temp.swtest.ru/f.jpg" width="300px" height="300px">
              <h1 style="color: white" class="bottom-left">Favorites</h1>
			</div>
	        </a>
	        
	        <a href="http://soniasonec.temp.swtest.ru/playlist/recomends.php">
            <div class="image" data-tilt data-tile-genre>
              <img class="genre" src="http://soniasonec.temp.swtest.ru/rec3.jpg" width="300px" height="300px">
              <h1 style="color: white" class="bottom-left">Recommends</h1>
			</div>
	        </a>
        
        ';
        
        
    } else{
        echo '
        
            <a href="http://soniasonec.temp.swtest.ru/playlist/rnb.php">
            <div class="image" data-tilt data-tile-genre>
              <img class="genre" src="http://soniasonec.temp.swtest.ru/images/fTIlJUJQCKpTboW.webp" width="300px" height="300px">
              <h1 style="color: white" class="bottom-left">R&B</h1>
			</div>
	        </a>
	        
	        <a href="http://soniasonec.temp.swtest.ru/playlist/rap.php">
            <div class="image" data-tilt data-tile-genre>
              <img class="genre" src="http://soniasonec.temp.swtest.ru/images/LbUafliSxMELZlr.webp" width="300px" height="300px">
              <h1 style="color: white" class="bottom-left">Rap</h1>
			</div>
        	</a>
        
        ';
        
    }
    
    ?>


    <a href='http://soniasonec.temp.swtest.ru/playlist/rock.php'>
            <div class="image" data-tilt data-tile-genre>
              <img class="genre" src="http://soniasonec.temp.swtest.ru/metal.webp" width="300px" height="300px">
              <h1 style="color: white" class="bottom-left">Rock</h1>
			</div>
	</a>
	
	    <a href='http://soniasonec.temp.swtest.ru/playlist/pop.php'>
            <div class="image" data-tilt data-tile-genre>
              <img class="genre" src="https://assets.vogue.com/photos/5e332d1c2331ef0008ee8955/4:3/w_1080,h_810,c_limit/lipa-promo.jpg" width="300px" height="300px">
              <h1 style="color: white" class="bottom-left">Pop</h1>
			</div>
	</a>
	
	
	    <a href='http://soniasonec.temp.swtest.ru/playlist/indie.php'>
            <div class="image" data-tilt data-tile-genre>
              <img class="genre" src="https://upload.wikimedia.org/wikipedia/commons/e/e7/%22AM%22_%28Arctic_Monkeys%29.jpg" width="300px" height="300px">
              <h1 style="color: white" class="bottom-left">Indie</h1>
			</div>
	</a>
	
	    <a href='http://soniasonec.temp.swtest.ru/playlist/country.php'>
            <div class="image" data-tilt data-tile-genre>
              <img class="genre" src="https://hips.hearstapps.com/hmg-prod/images/gjc7rxxxoaetirs-65f9bf9354d93.jpeg?crop=1.00xw:1.00xh;0,0&resize=1200:*" width="300px" height="300px">
              <h1 style="color: white" class="bottom-left">Country</h1>
			</div>
	</a>
	
		    <a href='http://soniasonec.temp.swtest.ru/playlist/classic.php'>
            <div class="image" data-tilt data-tile-genre>
              <img class="genre" src="https://upload.wikimedia.org/wikipedia/commons/thumb/1/1e/Wolfgang-amadeus-mozart_1.jpg/1200px-Wolfgang-amadeus-mozart_1.jpg" width="300px" height="300px">
              <h1 style="color: white" class="bottom-left">Classic</h1>
			</div>
	</a>
	
		    <a href='http://soniasonec.temp.swtest.ru/playlist/edm.php'>
            <div class="image" data-tilt data-tile-genre>
              <img class="genre" src="https://i1.sndcdn.com/artworks-000355816539-zb5tz4-t500x500.jpg" width="300px" height="300px">
              <h1 style="color: white" class="bottom-left">EDM</h1>
			</div>
	</a>
	
	<a href='http://soniasonec.temp.swtest.ru/playlist/jazz.php'>
            <div class="image" data-tilt data-tile-genre>
              <img class="genre" src="https://lastfm.freetls.fastly.net/i/u/300x300/d19f8e0c2aefcdced1de15261307f69f.jpg" width="300px" height="300px">
              <h1 style="color: white" class="bottom-left">Jazz</h1>
			</div>
	</a>

	
	
	
	
			</div>
        </div>
            
            
                
                
                
                </div>
            </div>
        </div>
    </div>
    <script src="script.js"></script>
</body>
</html>