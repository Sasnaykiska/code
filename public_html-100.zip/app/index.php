<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel = "icon" href = "logo2.png" type = "image/x-icon">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <script src="https://kit.fontawesome.com/6feed9d60e.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="style.css">
    <script src="../wave.js"></script>
    <title>Waves</title>
    <style>
    h1{
        color: black;
        font-size: 25px;
    }
    h3{
        color: black;
        font-size: 20px;
    }

    footer {
        background-color: #f4f4f4;
        padding: 20px 0;
        width: 100%;
        bottom: 0;
        left: 0;
        display: flex;
        justify-content: center;
    }

    .footer-container {
        display: grid;
        grid-template-columns: repeat(3, 1fr); /* 3 равные колонки */
        gap: 20px;
        width: 100%;
        padding: 0 20px;
        justify-items: center;
    }

    .footer-column {
        display: flex;
        flex-direction: column;
    }

    .footer-column h4 {
        margin-bottom: 15px;
        font-size: 25px;
        color: #333;
    }

    .footer-column a {
        text-decoration: none;
        margin-bottom: 10px;
        color: #333;
        transition: color 0.3s ease;
        font-size: 15px;
    }

    .footer-column a:hover {
        color: #000;
    }

    .social-media {
        display: flex;
        gap: 10px;
    }

    .social-media a {
        font-size: 24px;
        color: #333;
        transition: color 0.3s ease;
    }

    .social-media a:hover {
        color: #000;
    }

    /* Адаптивность для мобильных устройств */
    @media (max-width: 768px) {
        .footer-container {
            grid-template-columns: 1fr; /* 1 колонка на мобильных устройствах */
            text-align: center;
        }

        .footer-column {
            align-items: center;
        }
    }
    </style>
</head>
<body>
    <div class="sidebar" style="left: -250px;">
        <a href="#">
        <img src="logo2.png" style="height: 40px; width: 40px;"/>
        </a>
        <br>
        <br>
        <div class="side-nav">
            <div class="item">
                <i class='bx bx-search-alt' ></i>
                <a href="#">Home</a>
            </div>
            <div class="item">
                <i class='bx bx-message-square-dots'></i>
                <a href="#">Playlists</a>
            </div>
            <div class="item">
                <i class='bx bx-briefcase'></i>
                <a href="#">Upload</a>
            </div>
            <div class="item">
                <i class='bx bx-bookmark-minus'></i>
                <a href="#">Favorites</a>
            </div>
            <div class="item">
                <i class='bx bx-cog'></i>
                <a href="#">Log Out</a>
            </div>
        </div>
        <div class="side-profile" style="visibility: hidden;">
            <div class="info">
                <img src="assets/profile-1.png">
                <a href="#">Alex.Talent</a>
                <p>Graphic Designer</p>
            </div>
            <div class="skills">
                <h5>Skills and Expertise</h5>
                <div class="skill-tags">
                    <div class="item">
                        <p>Graphic Designer</p>
                    </div>
                    <div class="item">
                        <p>Illustrator</p>
                    </div>
                    <div class="item">
                        <p>Photoshop</p>
                    </div>
                    <div class="item">
                        <p>HTML/CSS</p>
                    </div>
                </div>
            </div>
            <button>View Profile</button>
        </div>

    </div>
    <div class="container">
        <div class="nav">
            <button id="menuToggle"><i class='bx bx-menu'></i></button>
            <div class="search">
                <i class='bx bx-search'></i>
                <form id="searchForm" action="search.php" method="post" enctype="multipart/form-data">
                <input type="text" name="name" placeholder="Search for songs or authors">
                </form>
            </div>
            <button type="button" onclick="document.getElementById('searchForm').submit();">Search</button>
            <?php   
            if(!empty($_COOKIE["login"])){
            echo "
            <a href='https://example.com'>
            <div class='user-info'>

                <img src='assets/profile-1.png'>
                <div class='user-name'>
                <a href='#' class='user-name'>Reza.UI</a>
                </div>
 
            </div>
            </a>   
            ";    
            }
            ?>

        </div>
        <div class="main">
            <div class="content">
            <div class="header" >
                    <h4>Popular Playlists</h4>
                </div>    
            
                <br>
    <div class="d-flex justify-content-between" style="" id="ge">
    <div class="col results" id="co">  
    <a href='http://soniasonec.temp.swtest.ru/playlist/50.php'>
            <div class="image" data-tilt data-tile-genre>
              <img class="genre" src="50.png" width="300px" height="300px">
              <h1 style="color: white" class="bottom-left"></h1>
			</div>
	</a>
    
    
    
    
    <?php
    if(!empty($_COOKIE["login"])){
        echo '
        
            <a href="http://soniasonec.temp.swtest.ru/playlist/favorites.php">
            <div class="image" data-tilt data-tile-genre>
              <img class="genre" src="http://soniasonec.temp.swtest.ru/app/fav.jpg" width="300px" height="300px">
              <h1 style="color: white" class="bottom-left">Favorites</h1>
			</div>
	        </a>
	        
	        <a href="http://soniasonec.temp.swtest.ru/playlist/recomends.php">
            <div class="image" data-tilt data-tile-genre>
              <img class="genre" src="http://soniasonec.temp.swtest.ru/rec3.jpg" width="300px" height="300px">
              <h1 style="color: white" class="bottom-left">Recommends</h1>
			</div>
	        </a>
        
        ';
        
        
    } else{
        echo '
        
            <a href="http://soniasonec.temp.swtest.ru/playlist/rnb.php">
            <div class="image" data-tilt data-tile-genre>
              <img class="genre" src="http://soniasonec.temp.swtest.ru/images/fTIlJUJQCKpTboW.webp" width="300px" height="300px">
              <h1 style="color: white" class="bottom-left">R&B</h1>
			</div>
	        </a>
	        
	        <a href="http://soniasonec.temp.swtest.ru/playlist/rap.php">
            <div class="image" data-tilt data-tile-genre>
              <img class="genre" src="http://soniasonec.temp.swtest.ru/images/LbUafliSxMELZlr.webp" width="300px" height="300px">
              <h1 style="color: white" class="bottom-left">Rap</h1>
			</div>
        	</a>
        
        ';
        
    }
    
    ?>


    <a href='http://soniasonec.temp.swtest.ru/playlist/rock.php'>
            <div class="image" data-tilt data-tile-genre>
              <img class="genre" src="http://soniasonec.temp.swtest.ru/metal.webp" width="300px" height="300px">
              <h1 style="color: white" class="bottom-left">Rock</h1>
			</div>
	</a>
	
	    <a href='http://soniasonec.temp.swtest.ru/playlist/pop.php'>
            <div class="image" data-tilt data-tile-genre>
              <img class="genre" src="https://assets.vogue.com/photos/5e332d1c2331ef0008ee8955/4:3/w_1080,h_810,c_limit/lipa-promo.jpg" width="300px" height="300px">
              <h1 style="color: white" class="bottom-left">Pop</h1>
			</div>
	</a>
	
	
	    <a href='http://soniasonec.temp.swtest.ru/playlist/indie.php'>
            <div class="image" data-tilt data-tile-genre>
              <img class="genre" src="https://upload.wikimedia.org/wikipedia/commons/e/e7/%22AM%22_%28Arctic_Monkeys%29.jpg" width="300px" height="300px">
              <h1 style="color: white" class="bottom-left">Indie</h1>
			</div>
	</a>
	
	    <a href='http://soniasonec.temp.swtest.ru/playlist/country.php'>
            <div class="image" data-tilt data-tile-genre>
              <img class="genre" src="https://hips.hearstapps.com/hmg-prod/images/gjc7rxxxoaetirs-65f9bf9354d93.jpeg?crop=1.00xw:1.00xh;0,0&resize=1200:*" width="300px" height="300px">
              <h1 style="color: white" class="bottom-left">Country</h1>
			</div>
	</a>
	
		    <a href='http://soniasonec.temp.swtest.ru/playlist/classic.php'>
            <div class="image" data-tilt data-tile-genre>
              <img class="genre" src="https://upload.wikimedia.org/wikipedia/commons/thumb/1/1e/Wolfgang-amadeus-mozart_1.jpg/1200px-Wolfgang-amadeus-mozart_1.jpg" width="300px" height="300px">
              <h1 style="color: white" class="bottom-left">Classic</h1>
			</div>
	</a>
	
		    <a href='http://soniasonec.temp.swtest.ru/playlist/edm.php'>
            <div class="image" data-tilt data-tile-genre>
              <img class="genre" src="https://i1.sndcdn.com/artworks-000355816539-zb5tz4-t500x500.jpg" width="300px" height="300px">
              <h1 style="color: white" class="bottom-left">EDM</h1>
			</div>
	</a>
	
	<a href='http://soniasonec.temp.swtest.ru/playlist/jazz.php'>
            <div class="image" data-tilt data-tile-genre>
              <img class="genre" src="http://soniasonec.temp.swtest.ru/app/frank.webp" width="300px" height="300px">
              <h1 style="color: white" class="bottom-left">Jazz</h1>
			</div>
	</a>
	
	<a href='http://soniasonec.temp.swtest.ru/playlist/blues.php'>
            <div class="image" data-tilt data-tile-genre>
              <img class="genre" src="https://d1bxnw4yi2rcwu.cloudfront.net/uploads/images/Stories/_1200x796_crop_center-center_82_line/JSRB_blogentryphoto1.jpg" width="300px" height="300px">
              <h1 style="color: white" class="bottom-left">Blues</h1>
			</div>
	</a>
	
	
		<a href='http://soniasonec.temp.swtest.ru/playlist/soul.php'>
            <div class="image" data-tilt data-tile-genre>
              <img class="genre" src="https://ecx.images-amazon.com/images/I/51lOxZc%2BLuL._SL500_.jpg" width="300px" height="300px">
              <h1 style="color: white" class="bottom-left">Soul</h1>
			</div>
	</a>
	
	
			</div>
        </div>
            
            
                
                
                <div class="header">
                    <h4>Popular Songs</h4>
                </div>
                
    <?php
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);
    $conn = new mysqli("localhost", "soniasonec", "spve_if4nShqj5xc", "soniasonec");
    if($conn->connect_error){
        die("Ошибка: " . $conn->connect_error);
    }
    /*
    //SELECT 
    songs.id AS song_id, 
    songs.name, 
    songs.author, 
    IF(fav.songid IS NOT NULL, 'yes', 'no') AS is_favorite
    FROM 
        songs
    LEFT JOIN 
        fav ON songs.id = fav.songid
    LEFT JOIN 
        users ON fav.userLogin = users.login
    WHERE 
        users.login = 'asd' OR users.login IS NULL;
        
    //SELECT 
    DISTINCT songs.id AS song_id, 
    songs.name, 
    songs.author, 
    IF(fav.songid IS NOT NULL, 'yes', 'no') AS is_favorite
    FROM 
        songs
    LEFT JOIN 
        fav ON songs.id = fav.songid AND fav.userLogin = 'asd'
    ORDER BY 
        songs.id;    
    
    */
    $sql = "SELECT name, author, image, music, songid, COUNT(*) as order_count FROM fav JOIN songs ON id = songid GROUP BY songid ORDER BY order_count DESC LIMIT 6;";
    $ID = 0;
    if($result = $conn->query($sql)){
    $rowsCount = $result->num_rows;
    foreach($result as $row){
    $postName = $row["name"];
    $postAuthor = $row["author"];
    $postImage = $row["image"];
    $postMusic = $row["music"];
    echo "
    <br>
    <div class='music-player' style=''>
        <img src='http://soniasonec.temp.swtest.ru/images/$postImage.jpg' id='playBtn$ID' class='cover' style='border-radius: 10px;'>
            <div class='info' style='margin-top: 20px;'>
                <div class='songInfo'>
                <a href='http://soniasonec.temp.swtest.ru/song.php?song=$postMusic'><h1 class='main' style='font-weight: 700; '>$postName</h1></a>
                <i id='dontlike' class='fa-regular fa-heart' name='likes' style='font-size: 30px;'></i>
                </div>
                <a href='http://soniasonec.temp.swtest.ru/author.php?auth=$postAuthor'><h3 class='sub' style=''>$postAuthor</h3></a>
                <div id='waveform$ID' name='wav' style='@media screen and (max-width: 768px) { #waveform$ID ::part(wrapper) { height: 25px } }' ></div>
                <div class='control-bar'>
                </div>
            </div>
        <script>
        playBtn$ID = document.getElementById('playBtn$ID');
        var wavesurfer$ID = WaveSurfer.create({
            container: '#waveform$ID',
            height: 40,
            waveColor: '#c3c3c3',
            progressColor: '#2b2b2b',
            barWidth: 2,
            responsive: true,
            hideScrollbar: true,
            barRadius: 10
        });
        wavesurfer$ID.load('http://soniasonec.temp.swtest.ru/mus/$postMusic.mp3');
        playBtn$ID.onclick = function(){
            wavesurfer$ID.playPause();
            if(playBtn$ID.src.match('play')){

            }
            else{

            }
        }
    if(window.innerWidth < 800){
    let wave$ID = document.getElementById('waveform$ID');
    wave$ID.setAttribute('style', '#waveform$ID ::part(wrapper) { height: 25px }');
    }
    </script>
    
        </div>
    
    ";
    $ID++; 
    }
}
    
    ?>
</div>
            </div>
            <br>
            <br>
        <div class="footer-container">
            <div class="footer-column">
                <h4>Company</h4>
                <a href="#">About Us</a>
                <a href="#">Careers</a>
                <a href="#">Press</a>
            </div>
            <div class="footer-column">
                <h4>Support</h4>
                <a href="#">Contact Us</a>
                <a href="#">Help Center</a>
                <a href="#">Privacy Policy</a>
            </div>
            <div class="footer-column">
                <h4>Follow Us</h4>
                <div class="social-media">
                    <a href="#"><i class='bx bxl-facebook'></i></a>
                    <a href="#"><i class='bx bxl-instagram'></i></a>
                    <a href="#"><i class='bx bxl-twitter'></i></a>
                    <a href="#"><i class='bx bxl-linkedin'></i></a>
                </div>
            </div>
        </div>
        <br>
            <p style="text-align: center ">&copy; 2024 Waves. Все права нарушены.</p>    
        </div>

    </div>
            
        </div>
    </div>
    
    <script src="script.js"></script>
</body>
</html>