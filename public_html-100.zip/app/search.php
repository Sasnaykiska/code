<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel = "icon" href = "logo2.png" type = "image/x-icon">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <script src="https://kit.fontawesome.com/6feed9d60e.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="style.css">
    <script src="../wave.js"></script>
    <title>Waves</title>
    <style>
    h1{
        color: black;
        font-size: 25px;
    }
    h3{
        color: black;
        font-size: 20px;
    }


    </style>
</head>
<body>
    <div class="sidebar" style="left: -250px;">
        <a href="#">
        <img src="logo2.png" style="height: 40px; width: 40px;"/>
        </a>
        <br>
        <br>
        <div class="side-nav">
            <div class="item">
                <i class='bx bx-search-alt' ></i>
                <a href="#">Home</a>
            </div>
            <div class="item">
                <i class='bx bx-message-square-dots'></i>
                <a href="#">Playlists</a>
            </div>
            <div class="item">
                <i class='bx bx-briefcase'></i>
                <a href="#">Upload</a>
            </div>
            <div class="item">
                <i class='bx bx-bookmark-minus'></i>
                <a href="#">Favorites</a>
            </div>
            <div class="item">
                <i class='bx bx-cog'></i>
                <a href="#">Log Out</a>
            </div>
        </div>
        <div class="side-profile" style="visibility: hidden;">
            <div class="info">
                <img src="assets/profile-1.png">
                <a href="#">Alex.Talent</a>
                <p>Graphic Designer</p>
            </div>
            <div class="skills">
                <h5>Skills and Expertise</h5>
                <div class="skill-tags">
                    <div class="item">
                        <p>Graphic Designer</p>
                    </div>
                    <div class="item">
                        <p>Illustrator</p>
                    </div>
                    <div class="item">
                        <p>Photoshop</p>
                    </div>
                    <div class="item">
                        <p>HTML/CSS</p>
                    </div>
                </div>
            </div>
            <button>View Profile</button>
        </div>

    </div>
    <div class="container">
        <div class="nav">
            <button id="menuToggle"><i class='bx bx-menu'></i></button>
            <div class="search">
                <i class='bx bx-search'></i>
                <input type="text" placeholder="Search for songs or authors">
            </div>
            <button>Search</button>
            <?php   
            if(!empty($_COOKIE["login"])){
            echo "
            <a href='https://example.com'>
            <div class='user-info'>

                <img src='assets/profile-1.png'>
                <div class='user-name'>
                <a href='#' class='user-name'>Reza.UI</a>
                </div>
 
            </div>
            </a>   
            ";    
            }
            ?>

        </div>
        <div class="main">
            <div class="content">
            <div class="header" >
                    <h4>Popular Playlists</h4>
                </div>    
            
            
                <div id="songs-list" class="songs-container">
                    <!-- Песни будут загружены сюда -->
                </div>

                <div id="loading" class="loader" style="display: none;">Loading...</div>
                
                </div>
            </div>
        </div>
    </div>
    <script src="script.js"></script>
    <script>
        let currentPage = 1;
        let isLoading = false;

        // Функция для получения песен с сервера
        async function fetchSongs(page) {
            isLoading = true;
            document.getElementById('loading').style.display = 'block';

            try {
                const response = await fetch(`songs.php?page=${page}`);
                if (!response.ok) {
                    throw new Error('Ошибка при загрузке данных с сервера');
                }
                const data = await response.json();
                return data;
            } catch (error) {
                console.error('Ошибка при загрузке песен:', error);
                return [];
            } finally {
                isLoading = false;
                document.getElementById('loading').style.display = 'none';
            }
        }

        // Функция для отображения песен
        function renderSongs(songs) {
            const songList = document.getElementById('songs-list');

            if (!songs || songs.length === 0) {
                //console.log('Нет новых песен для загрузки.');
                return;
            }

            songs.forEach(song => {
                const songItem = document.createElement('div');
                //songItem.className = 'music-player';
                songItem.innerHTML = `
                <br>
                <div class='music-player' id='play'>
                    <img src='http://soniasonec.temp.swtest.ru/images/${song.image}.jpg' loading='lazy' id='img' class='cover' style='border-radius: 10px;'>
                    <div class='info'>
                        <div class='songInfo'>
                            <a href='http://soniasonec.temp.swtest.ru/song.php?song=${song.music}'><h1 class='main'>${song.name}</h1></a>
                            <i class='fa-regular fa-heart' style='font-size: 30px;'></i>
                        </div>
                        <a href='http://soniasonec.temp.swtest.ru/author.php?auth=${song.author}'><h3 class='sub'>${song.author}</h3></a>
                        <audio controls='controls' id='audio' style='width:100%; preload='none'>
                            <source src='http://soniasonec.temp.swtest.ru/music/${song.music}.mp3'>
                        </audio>
                    </div>
                </div>
                `;

                songList.appendChild(songItem);
            });
        }

        // Функция для загрузки песен при прокрутке страницы
        async function loadMoreSongs() {
            if (isLoading) return;

            const scrollPosition = window.innerHeight + window.scrollY;
            const documentHeight = document.body.scrollHeight;

            if (scrollPosition >= documentHeight - 100) {
                const songs = await fetchSongs(currentPage);
                if (songs.length > 0) {
                    renderSongs(songs);
                    currentPage++;
                } else {
                    console.log('Все песни загружены.');
                    window.removeEventListener('scroll', loadMoreSongs);  // Отключить бесконечную прокрутку
                }
            }
        }

        // Начальная загрузка песен
        loadMoreSongs();

        // Слушаем событие прокрутки
        window.addEventListener('scroll', loadMoreSongs);
    </script>
</body>
</html>