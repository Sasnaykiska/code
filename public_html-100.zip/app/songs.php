<?php
// Устанавливаем заголовки, чтобы возвращать данные в формате JSON
header('Content-Type: application/json');

// Подключаемся к базе данных (измените на ваши параметры)
// Имя вашей базы данных

// Создаем соединение
$conn = new mysqli("localhost", "soniasonec", "spve_if4nShqj5xc", "soniasonec");

// Проверяем соединение
if ($conn->connect_error) {
    die(json_encode(['error' => 'Ошибка подключения к базе данных: ' . $conn->connect_error]));
}

// Получаем текущую страницу из параметров запроса (по умолчанию 1)
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 10;  // Количество песен на страницу
$offset = ($page - 1) * $limit;

// SQL-запрос для выборки песен с пагинацией
$sql = "SELECT id, name, author, image, music FROM songs LIMIT $limit OFFSET $offset";
$result = $conn->query($sql);

// Проверяем, если записи найдены
if ($result->num_rows > 0) {
    $songs = [];

    // Извлекаем данные для каждой песни
    while ($row = $result->fetch_assoc()) {
        $songs[] = [
            'id' => $row['id'],
            'name' => $row['name'],
            'author' => $row['author'],
            'image' => $row['image'],
            'music' => $row['music']
        ];
    }

    // Возвращаем данные в формате JSON
    echo json_encode($songs);

} else {
    // Если песен не найдено, возвращаем пустой массив
    echo json_encode([]);
}

// Закрываем соединение
$conn->close();
?>