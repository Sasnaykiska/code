<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel = "icon" href = "logo2.png" type = "image/x-icon">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="style.css">
    <script src="../wave.js"></script>
    <title>Waves</title>
    <style>
    h1{
        color: black;
        font-size: 25px;
    }
    h3{
        color: black;
        font-size: 20px;
    }


    </style>
</head>
<body>
    <div class="sidebar" style="left: -250px;">
        <a href="#">
        <img src="logo2.png" style="height: 40px; width: 40px;"/>
        </a>
        <div class="side-nav">
            <div class="item">
                <i class='bx bx-search-alt' ></i>
                <a href="#">Home</a>
            </div>
            <div class="item">
                <i class='bx bx-message-square-dots'></i>
                <a href="#">Playlists</a>
            </div>
            <div class="item">
                <i class='bx bx-briefcase'></i>
                <a href="#">Upload</a>
            </div>
            <div class="item">
                <i class='bx bx-bookmark-minus'></i>
                <a href="#">Favorites</a>
            </div>
            <div class="item">
                <i class='bx bx-cog'></i>
                <a href="#">Log Out</a>
            </div>
        </div>
        <div class="side-profile" style="visibility: hidden;">
            <div class="info">
                <img src="assets/profile-1.png">
                <a href="#">Alex.Talent</a>
                <p>Graphic Designer</p>
            </div>
            <div class="skills">
                <h5>Skills and Expertise</h5>
                <div class="skill-tags">
                    <div class="item">
                        <p>Graphic Designer</p>
                    </div>
                    <div class="item">
                        <p>Illustrator</p>
                    </div>
                    <div class="item">
                        <p>Photoshop</p>
                    </div>
                    <div class="item">
                        <p>HTML/CSS</p>
                    </div>
                </div>
            </div>
            <button>View Profile</button>
        </div>

    </div>
    <div class="container">
        <div class="nav">
            <button id="menuToggle"><i class='bx bx-menu'></i></button>
            <div class="search">
                <i class='bx bx-search'></i>
                <input type="text" placeholder="Search for jobs or companies">
            </div>
            <button>Search</button>
            <div class="user-info">
                <img src="assets/profile-1.png">
                <div class="user-name">
                    <a href="#" class="user-name">Reza.UI</a>
                </div>
            </div>
        </div>
        <div class="main">
        <div class="content">
        <br>
        <div class='music-player2' style='width: 100%; height: 85vh;'>
            <br>
            <img class="user-photo" src="assets/profile-1.png">
            <br>
            <h1>Kirill</h1>
            <br>
            <div class='music-player' style='display: flex; height: 60px;'>
                <h1 class='main' style='font-weight: 900;'>Изменить изображение</h1>
            </div>
            <br>
            <div class='music-player' style='display: flex; height: 60px;'>
                <h1 class='main' style='font-weight: 900;'>Изменить имя</h1>
            </div>
            <br>
            <div class='music-player' style='display: flex; height: 60px;'>
                <h1 class='main' style='font-weight: 900; color: #ae2f2f;'>Выйти</h1>
            </div>   
        </div>
                </div>
            </div>
        </div>
    </div>
    <script src="script.js"></script>
</body>
</html>