 <?php
        $link = $_GET["link"];
        $conn = new PDO('mysql:host=localhost;dbname=soniasonec', 'soniasonec', 'spve_if4nShqj5xc');
        $sql = "DELETE FROM `playlist` WHERE link = '$link'";
        if($result = $conn->query($sql)){
         
          header('Location: http://soniasonec.temp.swtest.ru/changePlaylist.php');
            
        }

         ?>