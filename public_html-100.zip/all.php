<?php

//ini_set('display_errors', 1);

//ini_set('display_startup_errors', 1);

//error_reporting(E_ALL);

function get_data()

{

	$conn = new mysqli("localhost", "soniasonec", "spve_if4nShqj5xc", "soniasonec");

	$sql = "SELECT * FROM `songs` ORDER BY id DESC;";

	$res = mysqli_query($conn, $sql);

	$emp = array();

	while ($row = mysqli_fetch_array($res)) {

	$emp[] = [

	

      "id" => $row["id"],

	    "name" => $row["name"],

	    "artist" => $row["author"],

	    "src" => $row["music"],

	    "img" => $row["image"],

	    "color" => $row["imageColor"]

			

		];

	}

	return json_encode($emp);

}

$data = ''.(get_data())."";

?>

<!DOCTYPE html>

<html lang="en">

<head>

  <meta charset="UTF-8">

  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <title>Waves</title>

  <link rel = "icon" href = "logo.png" type = "image/x-icon">
  
  <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

  <link rel="stylesheet" href="/css/st.css">

  <script src="https://kit.fontawesome.com/6feed9d60e.js" crossorigin="anonymous"></script>

  <style>
  .play-pause{
      font-size: 30px;
  }
  body{
      background-position: center;
  }
  .audio-duration{
      
        font-size: 47px;
        color: white;
  }
  .fit-picture{
      height: 70px;
      width: 70px;
      border-radius: 10px;
      padding: 5px;
      margin-right: 5px;
  }
  
  .music-list{
      backdrop-filter: blur(20px);
  }

  background-image{

  opacity: 0.33;

  }

  body{

    background-size: 200%;

    background-position: center;

    backdrop-filter: blur(200px);

    -webkit-backdrop-filter: blur(90px);

  }

  i{

      color: #1E90FF;

  }

  nav{

      display: flex;

      justify-content: space-between;

      margin-bottom: 30px;

    }

    @media (max-width: 1000px) {

      .song-details p{

        text-align: start;

        margin-left: 6%;



      }

    }

    

    @media (min-width: 1000px) {

      .wrapper{

          margin-top: 5%;

      }

    }

    

    i{

        color: white;

    }

    
    @media (max-width: 700px) {
        body{
            overflow-x: hidden;
        }

    .music-list.show {
    
        overflow-x: hidden;
        
    }
    }
    
    @media (max-width: 380px) {
    .mus-list{
    }
    }
    #next{
        font-size: 30px;
    }
    #prev{
        font-size: 30px;
    }
    #more-music{
        font-size: 30px;
    }
    #repeat-plist{
        font-size: 30px;
    }
  </style>

</head>

<body>

  <div class="wrapper">

        <nav>

          <div class="circle">

            <a href="../index.php"><i class="fa-solid fa-house"></i></a>

          </div>
          <div class="circle">

            <a href="classic.php"><i class="fa-solid fa-chevron-right"></i></a>

          </div>

        </nav>

    <div class="img-area">

      <img loading="lazy" src="" alt="" class="image" id="ima">

    </div>

    <div class="song-details">

      <p class="name"></p>

      <p class="artist"></p>

    </div>

    <div class="progress-area">

      <div class="progress-bar">

        <audio id="main-audio" src=""></audio>

      </div>

      <div class="song-timer">

        <span class="current-time">0:00</span>

        <span class="max-duration">0:00</span>

      </div>

    </div>

    <div class="controls">
        
        <i id="repeat-plist" class="material-icons" title="Playlist looped" style="display: none;">repeat</i>
        
        <i id="repeat-plist" class="fa-solid fa-repeat" title="Playlist looped"></i>

        <i id="prev" class="fa-solid fa-backward"></i>

      <div class="play-pause">
        
        <i style="font-size: 50px;" class="material-icons play">play_arrow</i>

      </div>
        
        <i id="next" class="fa-solid fa-forward"></i>
        
        <i id="more-music" class="fa-solid fa-list-ul"></i>

    </div>

    <div class="music-list">

      <div class="header">

        <div class="row">

        </div>

        <i id="close" class="material-icons">close</i>

      </div>

      <ul>

      </ul>

    </div>

  </div>

  <script>

      let allMusic = <?php echo $data ?>

  </script>
  
    <script>

    if(window.innerWidth < 700){
        
        let first = "five", second = "six"
        let string = `${first} + ${second} = 11`
        var win = window.innerWidth;
        //alert(win);
        const divContainer = document.getElementsByClassName("music-list");
        divContainer.setAttribute("style", `max-width: 200px`);
    }

  </script>

  <!--<script src="test2.js"></script>-->

  <script src="/js/norm2.js"></script>



</body>

</html>