<?php
	if (isset($_POST['getData'])) {
		$conn = new mysqli('localhost', 'soniasonec', 'spve_if4nShqj5xc', 'soniasonec');

		$start = $conn->real_escape_string($_POST['start']);
		$limit = $conn->real_escape_string($_POST['limit']);
		$author = $conn->real_escape_string($_POST['author']);
		          /*
        $sql = "SELECT name, author, music, image FROM songs WHERE author like '%$author%' ORDER BY id DESC LIMIT $start, $limit;";
        if($result = $conn->query($sql)){
        $rowsCount = $result->num_rows;
        foreach($result as $row){
  			*/
		$sql = $conn->query("SELECT name, author, music, image FROM songs WHERE author like '%$author%' ORDER BY id DESC LIMIT $start, $limit");
		if ($sql->num_rows > 0) {
			$response = "";
			while($data = $sql->fetch_array()){
    $ID = $data["id"];
    $postName = $data["name"];
    $postAuthor = $data["author"];
    $postImage = $data["image"];
    $postColor = $data["imageColor"];
    $postMusic = $data["music"];
    $response .= "
    <br>
    <div class='music-player' id='play'>
        <img src='http://soniasonec.temp.swtest.ru/images/$postImage.jpg' id='img' class='cover' style='border-radius: 10px;'>
            <div class='info'>
                <h1>$postName</h1>
                <h3>$postAuthor</h3>
                <audio controls='controls' id='audio' preload='metadata' style='width:100%; '>
                    <source src='http://soniasonec.temp.swtest.ru/music/$postMusic.mp3'>
                    </audio>
            </div>
    
        </div>
    
    ";
			}

			exit($response);
		} else{
			exit('reachedMax');
		}
	}
?>