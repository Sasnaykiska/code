<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
$conn = new mysqli("localhost", "soniasonec", "spve_if4nShqj5xc", "soniasonec");
if($conn->connect_error){
    die("Ошибка: " . $conn->connect_error);
}
$sql = "SELECT * FROM users;";
if($result = $conn->query($sql)){
    $rowsCount = $result->num_rows;
    foreach($result as $row){
    $name = $row['login'];
    echo "
    <div>
    <h1>$name</h1>
    </div>
    ";
    }
}
?>