wavesurfer0.on('play', function () {
            wavesurfer1.pause();
            wavesurfer2.pause();
            wavesurfer3.pause();
            wavesurfer4.pause();
            wavesurfer5.pause();
        });
        
        wavesurfer1.on('play', function () {
            wavesurfer0.pause();
            wavesurfer2.pause();
            wavesurfer3.pause();
            wavesurfer4.pause();
            wavesurfer5.pause();
        });
        
        wavesurfer2.on('play', function () {
            wavesurfer0.pause();
            wavesurfer1.pause();
            wavesurfer3.pause();
            wavesurfer4.pause();
            wavesurfer5.pause();
        });
        
        wavesurfer3.on('play', function () {
            wavesurfer0.pause();
            wavesurfer1.pause();
            wavesurfer2.pause();
            wavesurfer4.pause();
            wavesurfer5.pause();
        });
        
        wavesurfer4.on('play', function () {
            wavesurfer0.pause();
            wavesurfer1.pause();
            wavesurfer2.pause();
            wavesurfer3.pause();
            wavesurfer5.pause();
        });
        
        wavesurfer5.on('play', function () {
            wavesurfer0.pause();
            wavesurfer1.pause();
            wavesurfer2.pause();
            wavesurfer3.pause();
            wavesurfer4.pause();

        });
        
        
        
        
        
        
        
        
        
        
        
        
        
{
  const formatTime = (seconds) => {
    const minutes = Math.floor(seconds / 60)
    const secondsRemainder = Math.round(seconds) % 60
    const paddedSeconds = `0${secondsRemainder}`.slice(-2)
    return `${minutes}:${paddedSeconds}`
}

  const wave0 = document.querySelector('#time0')
  wavesurfer0.on('timeupdate', (currentTime) => (wave0.textContent = formatTime(currentTime)))
  
  const wave1 = document.querySelector('#time1')
  wavesurfer1.on('timeupdate', (currentTime) => (wave1.textContent = formatTime(currentTime)))
  
  const wave2 = document.querySelector('#time2')
  wavesurfer2.on('timeupdate', (currentTime) => (wave2.textContent = formatTime(currentTime)))
  
  const wave3 = document.querySelector('#time3')
  wavesurfer3.on('timeupdate', (currentTime) => (wave3.textContent = formatTime(currentTime)))
  
  const wave4 = document.querySelector('#time4')
  wavesurfer4.on('timeupdate', (currentTime) => (wave4.textContent = formatTime(currentTime)))
  
  const wave5 = document.querySelector('#time5')
  wavesurfer5.on('timeupdate', (currentTime) => (wave5.textContent = formatTime(currentTime)))

}