<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <title>Аудиоплеер с эффектами</title>
    <style>
        #progress {
            width: 100%;
        }
        .controls {
            margin-top: 20px;
        }
    </style>
</head>
<body>
<div class="container">
<br>
    <h1>Аудиоплеер с эффектами</h1>
    <?php
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);
    $conn = new mysqli("localhost", "soniasonec", "spve_if4nShqj5xc", "soniasonec");
    if($conn->connect_error){
        die("Ошибка: " . $conn->connect_error);
    }
    $sql = "SELECT * FROM songs ORDER BY RAND() LIMIT 1";
    if($result = $conn->query($sql)){
    $rowsCount = $result->num_rows;
    foreach($result as $row){
    $postName = $row["name"];
    $postAuthor = $row["author"];
    $postImage = $row["image"];
    $postMusic = $row["music"];
    echo $postName;
    echo $postAuthor;
    }
}
?>

    <div class="controls">
        <progress id="progress" value="0" max="100"></progress>
        <button id="playPause">▶️ Воспроизвести</button>
        <input type="range" id="seek" min="0" max="100" value="0">
    </div>

    <div>
        <label for="irSelect">Выберите IR-эффект:</label>
        <select id="irSelect">






<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
// Директория, в которой находятся изображения
$directory = "ir/";

// Получаем список всех файлов в директории
$files = scandir($directory);

// Перебираем все файлы
foreach ($files as $file) {
    // Проверяем, что файл имеет расширение .jpeg или .jpg
    if (pathinfo($file, PATHINFO_EXTENSION) === 'wav') {
        // Полный путь к файлу
        $name = pathinfo($file, PATHINFO_FILENAME);

                echo"
                <option value='ir/$name.wav'>$name</option>
                ";
    
    }
}
?>
        </select>
    </div>

    <script>
    const audioContext = new (window.AudioContext || window.webkitAudioContext)();
let audioSource, gainNode, convolver;
let isPlaying = false;
let currentSongBuffer = null;

// Ссылка на песню (укажите свою)
const songUrl = '<?php echo "http://soniasonec.temp.swtest.ru/music/$postMusic.mp3";?>';

// Элементы управления
const playPauseButton = document.getElementById('playPause');
const progressBar = document.getElementById('progress');
const seekBar = document.getElementById('seek');
const irSelect = document.getElementById('irSelect');

// Загрузка песни при запуске
loadAudio(songUrl).then(() => {
    console.log('Песня загружена');
});

// Загрузка аудиофайла
async function loadAudio(url) {
    const response = await fetch(url);
    const arrayBuffer = await response.arrayBuffer();
    currentSongBuffer = await audioContext.decodeAudioData(arrayBuffer);
    setupAudioNodes();
}

// Настройка аудиоузлов
function setupAudioNodes() {
    if (audioSource) audioSource.stop(); // Останавливаем текущее воспроизведение

    audioSource = audioContext.createBufferSource();
    audioSource.buffer = currentSongBuffer;

    // Создаем узлы для эффектов
    gainNode = audioContext.createGain();
    convolver = audioContext.createConvolver();

    // Подключаем узлы
    audioSource.connect(convolver);
    convolver.connect(gainNode);
    gainNode.connect(audioContext.destination);

    // Обновляем IR-эффект
    updateIR(irSelect.value);

    // Обработка прогресса
    audioSource.onended = () => {
        isPlaying = false;
        playPauseButton.textContent = '▶️ Воспроизвести';
    };

    // Обновление полосы прогресса
    const updateProgress = () => {
        if (audioSource && audioSource.buffer) {
            const progress = (audioContext.currentTime / audioSource.buffer.duration) * 100;
            progressBar.value = progress;
            seekBar.value = progress;
            if (isPlaying) requestAnimationFrame(updateProgress);
        }
    };

    audioSource.start(0);
    isPlaying = true;
    playPauseButton.textContent = '⏸️ Пауза';
    updateProgress();
}

// Перемотка
seekBar.addEventListener('input', () => {
    if (audioSource && audioSource.buffer) {
        const seekTime = (seekBar.value / 100) * audioSource.buffer.duration;
        audioSource.stop();
        setupAudioNodes();
        audioSource.start(0, seekTime);
    }
});

// Воспроизведение/пауза
playPauseButton.addEventListener('click', () => {
    if (isPlaying) {
        audioSource.stop();
        isPlaying = false;
        playPauseButton.textContent = '▶️ Воспроизвести';
    } else {
        setupAudioNodes();
    }
});

// Обновление IR-эффекта
irSelect.addEventListener('change', () => {
    updateIR(irSelect.value);
});

// Загрузка и применение IR-эффекта
async function updateIR(irFile) {
    const response = await fetch(irFile);
    const arrayBuffer = await response.arrayBuffer();
    const irBuffer = await audioContext.decodeAudioData(arrayBuffer);
    convolver.buffer = irBuffer;
}    
        
    </script>
</div>
</body>
</html>