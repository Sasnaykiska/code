<?php
setcookie("login", '', time()-1000, "/");
header('Location: /');
?>