<!DOCTYPE html>
<html lang="en">
  <head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous"> 
    <link rel = "icon" href = "logo.png" type = "image/x-icon">
	<link rel="icon" href="logo.png" type="image/icon type">
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Waves</title>
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css"/>
   <script src="../bg.js" defer></script>
   <script src="wave.js"></script>
   <style>
  h1{
        color: black;
        font-size: 25px;
    }
    h3{
        color: black;
        font-size: 20px;
    }
    .cover{
        width: 160px;
        height: 160px;
        object-fit: cover;
    }
.image{
    position: relative;
    text-align: center;
    color: white;
}


.bottom-left {
    position: absolute;
    bottom: 8px;
    left: 30px;
}
.genre{
    object-fit: cover;
    width: 260px;
    height: 260px;
    border-radius: 10px;
    -webkit-box-shadow: 26px 33px 28px 1px rgba(34, 60, 80, 0.14);
    -moz-box-shadow: 26px 33px 28px 1px rgba(34, 60, 80, 0.14);
    box-shadow: 26px 33px 28px 1px rgba(34, 60, 80, 0.14);
}


.music-player{
background: rgba( 255, 255, 255, 0.2 );
box-shadow: 0 8px 32px 0 rgba( 31, 38, 135, 0.37 );
backdrop-filter: blur( 20px );
-webkit-backdrop-filter: blur( 20px );
border-radius: 10px;
border: 1px solid rgba( 255, 255, 255, 0.18 );
    width: 100%;
    height: 180px;
    border-radius: 15px;
    padding: 10px 18px;
    display: flex;
    align-items: center;
}

.info{
    margin-left: 40px;
    width: 100%;
}

.info h3{
    margin-bottom: 10px;
}

.control-bar{
    margin-top: 30px;
}

.control-bar img{
    height: 20px;
    margin-right: 10px;
    cursor: pointer;
}
.cover:hover{
    filter: brightness(80%);
}
        li{
            color: black;
        } 
   
@font-face {
    font-family: 'Visby';
    src: local('Visby Round CF Bold'), local('Visby-Round-CF-Bold'),
        url('VisbyRoundCF-Bold.woff2') format('woff2'),
        url('VisbyRoundCF-Bold.woff') format('woff'),
        url('VisbyRoundCF-Bold.ttf') format('truetype');
    font-weight: 700;
    font-style: normal;
  }
h3 {
    font-family: 'Visby';  
}
h1 {
    font-family: 'Visby';
	vertical-align: middle;
	font-size: 130%;
	line-height: 0.5;
	color: black;
	line-height: 1.5;
}

h2 {
    font-family: 'Visby';
	font-size: 100%;
	color: black;
}
.im{
    transition: 1s; 
	margin-top: 50px;
	width: 250px;
	height: 250px;
	margin: 10px auto 20px;
	border-radius: 20px;
	object-fit: cover;
}
 .myDiv {

	        border-radius: 35px;

	        padding: 20px;

	        float: left;

	        width: 290px;

	        background: rgba( 255, 255, 255, 0.2 );

			box-shadow: 0 8px 32px 0 rgba( 31, 38, 135, 0.37 );

			backdrop-filter: blur( 4px );

			-webkit-backdrop-filter: blur( 4px );

			border-top: 1px solid rgba( 31, 38, 135, 0.37 );

			border-left: 10px solid rgba(255, 255, 255, 255. 0.3);

	       

	      }


* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: "Poppins", sans-serif;
}
body {
  background-image: url("image.png");
  background-position: center center;

/* Background image doesn't tile */
background-repeat: no-repeat;

/* Background image is fixed in the viewport so that it doesn't move when
the content's height is greater than the image's height */
background-attachment: fixed;

/* This is what makes the background image rescale based
on the container's size */
background-size: cover;
}
.nav {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  padding: 15px 200px;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
  z-index: 100;
  backdrop-filter: blur(30px);
  -webkit-backdrop-filter: blur(30px)
}
.nav,
.nav .nav-links {
  display: flex;
  align-items: center;
}
.nav {
  justify-content: space-between;
  border-radius: 10px;
}
a {
  color: #fff;
  text-decoration: none;
}
.nav .logo {
  font-size: 22px;
  font-weight: 500;
}
.nav .nav-links {
  column-gap: 20px;
  list-style: none;
}
.nav .nav-links a {
  transition: all 0.2s linear;
}
.nav.openSearch .nav-links a {
  opacity: 0;
  pointer-events: none;
}
.nav .search-icon {
  color: black;
  font-size: 20px;
  cursor: pointer;
}
.nav .search-box {
  position: absolute;
  right: 250px;
  height: 45px;
  max-width: 555px;
  width: 100%;
  opacity: 0;
  pointer-events: none;
  transition: all 0.2s linear;
}
.nav.openSearch .search-box {
  opacity: 1;
  pointer-events: auto;
}
.search-box .search-icon {
  position: absolute;
  left: 15px;
  top: 50%;
  left: 15px;
  color: black;
  transform: translateY(-50%);
}
.search-box input {
  height: 100%;
  width: 100%;
  border: none;
  outline: none;
  border-radius: 6px;
  background-color: #fff;
  padding: 0 15px 0 45px;
}

.nav .navOpenBtn,
.nav .navCloseBtn {
  display: none;
}

/* responsive */
@media screen and (max-width: 1160px) {
    .genre{
        width: 200px;
        height: 200px;
    }
  .nav {
    padding: 15px 100px;
  }
  .nav .search-box {
    right: 150px;
  }
}
@media screen and (max-width: 950px) {
  .nav {
    padding: 15px 50px;
  }
  .nav .search-box {
    right: 100px;
    max-width: 400px;
  }
}
@media screen and (max-width: 768px) {
  .nav .navOpenBtn,
  .nav .navCloseBtn {
    display: block;
  }
  .nav {
    padding: 15px 20px;
  }
  .nav .nav-links {
    position: fixed;
    top: 0;
    left: -100%;
    height: 100%;
    max-width: 280px;
    width: 100%;
    padding-top: 100px;
    row-gap: 30px;
    flex-direction: column;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    backdrop-filter: blur(30px);
    -webkit-backdrop-filter: blur( 30px );
    border-radius: 15px;
    color:  red;
    transition: all 0.4s ease;
    z-index: 100;
  }
  .nav.openNav .nav-links {
    left: 0;
  }
  .nav .navOpenBtn {
    color: black;
    font-size: 20px;
    cursor: pointer;
  }
  .nav .navCloseBtn {
    position: absolute;
    top: 20px;
    right: 20px;
    color: black;
    font-size: 20px;
    cursor: pointer;
  }
  .nav .search-box {
    top: calc(100% + 10px);
    max-width: calc(100% - 20px);
    right: 50%;
    transform: translateX(50%);
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  }
}

@media screen and (max-width: 768px) {
    .container{
        margin-top: 50px;
    }
    .info{
    margin-top: 25px;

    }
    #ge{
       display: none;
    }
    #waveform ::part(wrapper) {
        height: 25px
    }
    #waveform2 ::part(wrapper) {
        height: 25px
    }
    #waveform3 ::part(wrapper) {
        height: 25px
    }
    #waveform7 ::part(wrapper) {
        height: 25px
    }
    #waveform8 ::part(wrapper) {
        height: 25px
    }
    #waveform9 ::part(wrapper) {
        height: 25px
    }
    h1{
        font-size: 15px;
    }
    h3{
        font-size: 10px;
    }
    .music-player{
        height: 100px;
    }
    .cover{
        height: 70px;
        width: 70px;
        border-radius: 5px;
    }

  .nav .navOpenBtn,
  .nav .navCloseBtn {
    display: block;
  }
  .nav {
    padding: 15px 20px;
  }
  .nav .nav-links {
    position: fixed;
    top: 0;
    left: -100%;
    height: 100%;
    max-width: 280px;
    width: 100%;
    padding-top: 100px;
    row-gap: 30px;
    flex-direction: column;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    backdrop-filter: blur(20px);
    -webkit-backdrop-filter: blur( 20px );
    border-radius: 15px;
    color:  red;
    transition: all 0.4s ease;
    z-index: 100;
  }
  .nav.openNav .nav-links {
    left: 0;
  }
  .nav .navOpenBtn {
    color: black;
    font-size: 20px;
    cursor: pointer;
  }
  .nav .navCloseBtn {
    position: absolute;
    top: 20px;
    right: 20px;
    color: black;
    font-size: 20px;
    cursor: pointer;
  }
  .nav .search-box {
    top: calc(100% + 10px);
    max-width: calc(100% - 20px);
    right: 50%;
    transform: translateX(50%);
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  }
}

   </style>
  </head>
  <body>
    <nav class="nav">
      <i class="uil uil-bars navOpenBtn"></i>
      <a href="index.php" class="logo"><h1 style="font-size: 130%;">Waves</h1></a>
      <ul class="nav-links">
        <i class="uil uil-times navCloseBtn"></i>
        <li><a href="search.php"><h1 style="font-family: "Mona";">Search</h1></a></li>
        <li><a href="upload.php"><h1 style="font-family: "Mona";">Upload</h1></a></li>
        <li><a href="player.php"><h1 style="font-family: "Mona";">Player</h1></a></li>
      </ul>
      <i class="uil uil-search search-icon" id="searchIcon" style="visibility: ;"></i>
      <div class="search-box">
        <i class="uil uil-search search-icon"></i>
        <input type="text" placeholder="Search here..." />
      </div>
    </nav>
    <div class="container">
    <br> 
    <br>
    <br>
    <br>
    <h1>Popular Playlists</h1>
    <div class="d-flex justify-content-between" style="" id="ge">
    <div class="col results" id="co" style="display: grid; grid-template-columns: repeat(3, 290px); grid-row-gap: 60px; grid-column-gap: 80px; justify-content: center; align-content: center;">   
    <a href='http://soniasonec.temp.swtest.ru/app/genre/rnb.php'>
            <div class="image" data-tilt data-tilt-glare>
              <img class="genre" src="http://soniasonec.temp.swtest.ru/images/fTIlJUJQCKpTboW.webp" width="300px" height="300px" data-tilt data-tilt-genre>
              <h1 style="color: white" class="bottom-left">R&amp;B</h1>
			</div>
	</a>
    <a href='http://soniasonec.temp.swtest.ru/app/genre/rap.php'>
            <div class="image">
              <img class="genre" src="http://soniasonec.temp.swtest.ru/images/LbUafliSxMELZlr.webp" width="300px" height="300px">
              <h1 style="color: white" class="bottom-left">Rap</h1>
			</div>
	</a>
    <a href='http://soniasonec.temp.swtest.ru/app/genre/rock.php'>
            <div class="image">
              <img class="genre" src="http://soniasonec.temp.swtest.ru/images/vEgvAKejcFPZENj.webp" width="300px" height="300px">
              <h1 style="color: white" class="bottom-left">Rock</h1>
			</div>
	</a>
	
	    <a href='http://soniasonec.temp.swtest.ru/app/genre/rnb.php'>
            <div class="image" data-tilt data-tilt-glare>
              <img class="genre" src="   data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMTEhUSExMWFhUVFxoWGBcYFxgaGRgYFxgWFxcXGBoYHSggGBslGxgXITEhJSorLi4uGB8zODMtNygtLisBCgoKDg0OGxAQGi0mICUvLS0uLy8tLy0tLS0tNS0tLSstLS0tLS0tLS8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIAOEA4QMBIgACEQEDEQH/xAAcAAACAgMBAQAAAAAAAAAAAAAABgQFAgMHAQj/xABMEAABAwEFBAYHBAUJBwUAAAABAAIDEQQFEiExBkFRcRMiYYGRoTJCUrHB0fAHFHLhIzNigpI0Q1NUorLC0vEVFhckNZOzY3PE4vL/xAAaAQACAwEBAAAAAAAAAAAAAAAABAECAwUG/8QALhEAAgIBBAAFAwIHAQAAAAAAAAECEQMEEiExEyIyQVEzYXEUgQUVQlKhsfCC/9oADAMBAAIRAxEAPwCuM4JIUP0zhaVJdDQlZ2eyFuY41XoW2zxUaRi+yOAB13L2yteRgI3q1sIxZkceXap8VjaBWgqiyUm0LV4SFoDeynLiB2KC0E51+uSu71s2dSNFWdGDRTZK4VGAmIIruKtBLjYQK8RUKI6zUoc89O1bXvw5+t5clZMznRAbAcWY0S/trF1Gu4P94Kb3yNcO1LO2IpZ6ftNWeoV4Zfgb0OR/qI/mhHQhC8+esBCEIAEIQgAQhCABCEIAEIQgAQhCABCEIAEIQgAQhCAOwzOphIzHkrSBwIrSgNKqlMhphrv/ANQFZ3a4uH7OmY3j3rvuR46MOSyijFclK6NR44+xSWNyqs2xmMDHoAQSVS2myNLxQUHvTC08uCjW6NoANFKkEsZFlhy0yGWmiX7W3M80x2eUk0Omfgq+32UGpy+verQkY5IcWirjhNK0y3pW26fSNjeL6+A/MJz6SjaLnW21qxTBg0jbn+J2Z8sKpqp1hf34Nf4bjctSvtyLyELZHHVcQ9Sa0LZPCWmh7jxWtAAhCEACEIQAIQhAAhCEACEIQAIQhAAhCEACEIQB1ZoO4GoyqN6urlJpSmiktia/UfmrOzxACi7bZ5aMOTU1hpXit0cWWa2la3DtyVBhIxrnRe2luVNTu7EFwGSx6TggmiMLPQ1Fa0oeXBR54DUV3fBWBOaiXhamtGumvYrRsyyJUL1/2xsEbpHbhkOJ0A8VyS0TF7nPdmXEk8yrza6/PvEmFp/Rs0/aPtcuCoEhqs297V0jq6DTeFByl2/9G2zQl5wjU6dqsLrhbj6OQ4HadbTvO7n/AKqtglLXBzTQtII7k/wWOG3RBzurJSgcOO/z1CQyT2rk6UVYu31ZDGML2UpoeB/08VJ2S2eitTnYn0awVwg0c7mSDQch807tucvjEJDchhodKbiwnQfsHIbiEmXpcdosMokEb+j9YtFW038u/QgZrKGRtUXcUma9p9m2RdeCuEekCa/wk6pWXWdkLb97Y9jJ3OIFOinDSD2VboO1c32hsfQ2iSOhFDodRXcacDUV3671pjk+mVmvdFchCFqUBCEIAEIQgAQhCABCEIAEIQgAQhCAO6WO0fnmrOGXRcwu3bVmkrS08W5j5jwKabt2js8gylbXhWh8CuxHJCfTPOSxZMfqixs6RYPfnp5qtjtgPrDxWT7SBnVTtBTRNdKsQ8byqO17RwR+lIwcz8NUs3r9oDNImF/a7qt+apKUY+pmkITn6Ff/AHyOl5XkyNhc5waANSaZLl21O1brRWOOrYtCdC/nwHYqe9b3ltDsUjq00aMmjkFBSeXU7ltj0dHBo1F7p8v/AAgQhCVHgW6yWySJ2KN7mHiD7xoe9aVsihLnNY0Vc4hoHaTQBAHQdl9tppCIpIBIQKl7ThoBvcCKDuondl9QOAa4SRk13Nc001FM6eAKVdnrqZFG1jfWYXOf7RJydywsdTseFnaLQyJrJJCAQADWtMWEVOXGmnBczJNbqghuEbjbZf4Yg9s0b2gtrUEUJy3ggb6Lku2V4MntckjBkaN5looT5eSbGbT45A1sDi2Q0aatxVAFaVoCN/ivNo9nG2hhkiFJ2VqMOEyUGYcDQh3AnX3a47xS83uVn51wc6QgoTwsCEIQAIQhAAhCEACEIQAIQhAAhCEAC8XqEAetcRoSORXrpXHIuJ5krFCmyKR4vUIUEghCEACEIQABS7stBZLG8bntPgQfgoi22VoLwDpVD6BHULgeegb7QbhAO6mJprT8Q+CYIdkhNGHzCpJDgw6AgUqc9frXSs2Pu4xsbJJUYusGk6V0J7SPCp45PdnmDhRc/wAu77jXO05XtbZOjLsOXRYZm0qB1DheAaey7yT/AHDFFaYml/pNFQcg5uVNRqM8xoqzbC7A4tbTIhzTye0tz7yFP2BYegY53pBoDuwjI960vpMijln2oXJ93tWMCjZRU00xj0iOYIPPEk5dq+1y7ukspePShdjH4fRcPA17lxSqZxu0YSVM9QvF6rlQQhCABCEIAEIQgAQhCABCEIAEIQgAQgLIRHggizFC2iA8QsxZh7Xl+anayHOJHQpX3UcVkLI3ifL5KdrK+JEhrxTDZh2+P5Lz7sNKFG1k+JE0SwObTE0tqA4VFKgioPIhMuwVx9POJH/qousf2neq3lXXlTevL4gxARNaXSOfkAMxnSnZXNOVz2EWeBsANSc3kes4604NGg5cyksuesdrscjh89F394xOy04D3q0skp3Cp7M6Kou+eMmge0uBpQEZHeKa1TBYY6JKEXdjjSosY7M1464+ZPEqnt0X3V4liH6N3Vkbuz3hXLVqt1nD2OadHCnyKalyuDKKSfPRQ308SMcw5gtI5hwy8iuY2e7jpn5J+nm6tDTE0YXD3fHwS+0Cpy3n3quKcvk2x4oNu0n+xVjZsPGfuHyVDfWzb4cxmPrT5LoVmkU+2WVkkZrTMJmMn8hk0+N8VX4OIIVvtHYOjkJG8kHnqD3jzBVQtk7Vo5c4OEnFghCFJUEIQgAQhCABCEIAdIfs+kJzkDW9oGLwBI81YM2GgZ6T3uPYAPfVNklqaN6rpbc2uZXQWGCOLLU5H7lTJs1Zmj0XHm75UUKW54NzKfvO+at7ReDDq4eIUGa0x+2O6ivtgvZC7yZH7so7fdDQCWbt3FUjgmi0W1nFLdpw1OYpVL5lFeke0s5tVI0EoEhWDnt4hYmQcUvY7tN/TLNklacd1NVExjiptzFplbi0GdONBUDxUSnSslY7dDpc9lbDWaV1ZHCjWgeiOHPirWzOxuIJo4+IG6vb2JZvK1yMkbG1gxSw9Kxx1zDyDy6uWikXdaCx7X8aVXKyY5PmR2MMot0V1tsL453QmHpSQXNcw4ZMIzqPaI4aq/uplviwviNpEb60bNEKmmWmIkd4Fe1PEFjgtLGmRgLhod479ysY7LHAw4Qe9xPvW8Zpx5RR42pkO47fK6LFIATnUgUGXZuKXNo73tkkwghZOxrt7IxmBWvXeQ1mhTbc5HQyOHtCneVlbrBDKAZGYhwqad43qsKStlpr2RzLZ5xxSuLHtqCTjdic4tccy4ZEkA6ZLOJ3FXV7R4RNLGykbcMfVGTRhLW5DQYskri2AKl27HNPDai2ZJRT7Pa8qFLP+0Qs2XkrRlRvKKZo2zs1Wk/VRn8/FJFE92+cPYUlSswkjgUzhd2jk/xCO2Sl8mmi9otiKLejnbjVRC2ELEtRRZMxQhCgkEIQgB+Esf8ARtPOp95WbZ2boo/4AoYWQWtiCj9izitwH83H/Az5KVHeX7LP4W/JUrStgKrZdIs573/Zb/CPkq62Xu3fGw82N+SjTlU1tJWcrZpF0XsN6Rj+ai/7bPkpMe0cTPUj7mN+SRJpitGJVUBhSZ0+LbOMDJrP4W/JRbdtg0NdhZGGuzIwNzPKma582SinXJdzrVKGCuFoxOpuaPiTl/otKVER3OVIubU99oEc2Foa5oYSGAYAw4QGndk2gplmdMwJ1i62R1Cl3vBhgNMg3DQDKgaRkByVbd0lXZa+/sSWpVHUxY9rH/Z2egAqpu1Ej+hGCtCesRqBTs7VQ3ZaRSoOmvEHgVKs14TPJDJGcnAjLzr4JVP2GNrb4LrZu2tdAWCtchpvHFb7wkIaWtzO5RGWy0ZNBjxE6MBJdz/JMFmuRz4w5pq8khx9UbqDwW8IuXBjk8jtnOnMtQktLGscIXWWWPOnXe4AMwiuvSFmZ7UpOuK2/wBXf4t/zLsVqsgYzC0h8mKr8JqG0BDWk6VzefDgoXRv9h3h+abjhjRi8uZcpHJzcls/q0ngPmvW3LbP6tL4D5rqpDgaFp/NZiWit4ESktVmj2jl0Nx2w5fdpO/CB4k0TfN9ndmnhiLnugtAjY2TDR7HOaKVIJBB4kGmSvjOvDOrwxKPQtn1MsqSkI1s+ya0jOGeCUcKljvBwp5pWvvZW2WTOeB7W+1Srf4m1C7I21EaFTrPezgMJzByIOYI4EHIrSkLHzswDefDNbrPZDK7BECTStC5o0/EQK9i6ftrsHHKx1psLMEgGJ8A9F43uiHqu/Z0O6mh5TQFQ1QWSLXdM8YJfDI0DVxYcP8AEOr5qAmO6b0jBpIyGNwbQSNE8bjuIcbO7I034HKfbbrjn9Fwe/WrXNe/dn1Wsldl7UR/ENVG2yylQmoVx/u9JxHi3/MhV2stuXyTxbQs221qqpLI2tKNFMtwz1+uS8+4j2R3fkq+PH4NP5dk/uL1ltZxWwWxntDxS6buHsnzWJu3sP13I8aIfy/L8jHJaWEekPFVdunbnmFWSWEN1r9dywsVhdNI2KMVc40HDiSewCpUqafRnLSzi+WaZjmsY2Fxo0EngASfALot1bF2aMB07jIct5azuDeseZO5MZt1ks/6OPo2nSjaNB8BmVNDUNLL34OTNuWfIOjLK6Y+r5HPyXVPsmuBscUr30c9z6VbWmFoFBmOJKhXXZTbryD2NrBAKPBJGNwrVrR6xGIE9nMLq9nskUYwMAYNKAAdag3DU0p4hSuwjsxzFPbG6IvusxDethoOZIA965VAxzHdYUK7PtQSIwPacB4VJ9wSo642ymrkjqp+ejoJcWKk9oc2WMx+k8htNQ7mOwVNU27OuZO4xmzObK2po5pZiDTQuaTQOGmnFVLrGLPeNl3tDwBXfja6Mf2iE0WN1rlw2t9n6KaF72NiBzkhNKjPIP1INaEt4FVxYVKFk35qGK6rH0BxhrQ6lNK0rrzKXto7xtEsFraH0bG5wPq0Y0AkAAUqfir5l6RODDjaBIcLMRDau9ih9fI9XXIpfsMZtAtEY0faXhx4MY6h8cNO9OKMUlGJaEVblLsm7K2bo7EyuRdRx7OA8KLabzDnGKI1Ojn+qwDM58aV5Ly/CXFlliOHF6RHqsGVOyvw7VBvRrYukjjb1WsYygyqXEk1PbQAn9tadKgUdzt+5Ks9u6V3QwNJjb6Tz6556gHxPYNc5oWua5wNakkPGhOhp+zlQUyVdZZY6GHpA2Fh/Ty1p00m+KPfgByNPwjepVo2hjPVZAS0CgLj0Y4Cgpi8gpi/kpkgpcUV75KLU6YcVvtbRJGSDR9DhG6u6pSBNtCWkghwIJBFAKEZEekplJR7OTl0uSLqKsdTaAN6zZae1c+l2kduafJaW7RyVph373c+DeSjxIfJg9Pm/tOo2W9RGal1AMya6Lkm2VtgltcksDMMb8zuDn+u5o9UE5058V5et4yytpjAG9nWBPfSh8QqElDmnwiY4px9ao2tfxzVtYL3kbRjpS+IZdE8scKbsImY9gpwp4KjVrcFss7H/wDMwulYaHqvLXsIr1m7na6FQmDiNH+8cfsy/wAMH+ZC3f7burjbf+5/9UK5nz8Cy9tXPPFzj5miOiWMLiQPkFsBPAefzXOZ6SNV0DbOsnxECqyZIeHgfnVQ7wtxHVAp3/kiKbYZJxhG2V1pkJJTx9n9zubG+1U6x/V9oaQT4kU7km3bZHTytjG8504byuv3k8QwgMFA1oAA3UGVE7FHNwwc5bmLe09toaMPpAHuGnLJKtlu2Se0MjhFXSOH7pGZcewCp7lPvOTGce/6PvTD9ltmJndPTJv6NvPV/wDh81m3ya53xydb2ZuVlmhEYzzxEkAEuOrst6mWmw1LnAkZE6uJLqAZeyABlTeTlxLE8uOasAtkk0c+3Yh7SXpH0scLnOxkPOF7C00qMO4D0dDvo7gVHier/aWWMno2xsL83FxaAQTkMzmTSvKoS5C1c3U1vOpp23jVlJtzDSOO0N9KF4d3VBH9oDxXSGSVDXDQ0I5EJXtNjbKx0bs2vFD3qyua00s0bCauY3oyeLo+pXvw171rpJdo17ML4uZpeJhG19HtkdG6lC5mkrK5NlAyr6wyPFQtiH0glec/0r3E8c8Ve+qt7VbgC0ccvKqUrit/QwTRn1ZXt7qABNtJST/JpFNwd/YY7tNI5LU7Nzqu5NGg8kh3lfEk0hBOESdZwGtG0oK82t81Pt+1rGQGAGpw0pTef9UsQWxr52CmrMuzDu76+QWWWfFJmkaTbZfQFoDQ0BuHfv8AyG5W1ksEj29K2N3RZ9cDFpwaOsc+A+NK2yWbpHYd2p8lYTWDpDhcXOaMgCThAG5rdAO2izjkow1WVw4j2e2e8Y6kNitDgMqno2ivKpKq772cbaHdMx7WPI6zXsJBI0JcDUGlB6J0TvYrtY1gaAAANwXsl1SSA9GG19VzgcNeJAzI7Mua2vcqZz5Z8ifZyd+yVpH9D3OB97Vmdm56AYmkdao0AOEhujeJC6dbLjeyhIxVyq0ZV5HQL2C6HeyB5lR4cSv6vJ9jk52MtDsscQ73n/CtM32eWn1ZIX9lXA+baea7fZNn2A9cYuwlTzccG6NvgtYQVC+TLkk+T5mvjZ21WUAzwuY05B+TmHsxNJFezVVdF9YC6Yjk5jSOBC5ttn9lLHSumgk6IPPoYasDuylMNfrgomtvIQ83HuccwFCe/wDhXav6WP8AtIWfiR+TTwpfAusNN48/kssXaPrmtbHiiyL2pY7V8dmUk+EE5eI+apbRPiNVKt8opQLO5rkmtJPRNFG0q5xo0E6Cu88lvih7iGqySnLYh72AudrIhKR15Mz2DcB3K/t8VWuZTLOh7NaLC6bKYomMc6uFoaQwEk01z18gqbaG+Xg4BFK1vHo3Z95CY6RvCKjGhUvCYMJG5da2Iuc2eFjCM8ILvxOzd5k+SS9gbkNrtXTPYRFAatxA9eTIt19nXwTrZts2l9DAQ3iHdanaCKV7KpeUoxrcxTJuyNqPNDrBkFKbKqqy21kjA9hq0/RBG4qJfN8NhZiOpNAOeVTwA1JWykqsXjjlKW1Lk07XOBALRWQDP8PxPwKW7JaBRbp7Q41cCS6uLPfxHh7gqO8bVh/SAdU5mm47+7ek9TjcvMjrxw7IJIv3WuiXbdetoY57YA01e1+ZAoHBo36irXVpnmFCtN8H1Tqq+x2txmFfWBb8R7vNY4ZNSISt1Yw229HFzaerX3fJVUUjji/adU99M1umZU17FHAw59or3kj4hNOTY0YT3Iw1cSXOPcByA+NVT3e4GXCGULC4V7MJNfEBNj25aqkssf8AzFd2F58KD4rOQOPKov8AZe2gvbX1+rydrTxaR4J3bZc6rjJtnQl7S7DU42GuYcCHUprqPemp32ptDA1lnc99BUucGNrxGp9ymKEdVUmmuzqF1tGNoP0dyuMIbkFweT7Qrc89ToohuLWFx8Xkivcr+z7bXkwAPfBLl6T2AO78BaPJW8aMOxf9NOfKOryObhcXZNpmeCotmdo4Z55bLUdNFnT2m0BDm8daHge5cr2k2omtDaS4XZZBhcGt7gaE86pd2QthhtsNobUOjkBdSpxMJwyCh3lhKlZ1Ln2Ky0son0dJkVtaVqtDessmpuPQlLs2rLUUOi1hy9xUVip591Z7I816s0KNq+Cdz+T5PB+qBaLU4heF5UeSQlKxjydDJkVUYsaSQBqTQczknC4ZDC+KJtQDI1rzoC4kVBS7cUWKdmVQ04j3aedE4FjSHNIriNeRrWoPGq1ojTx/qHK8bVG1pcH0okqW0SWudsEWbjmXYSQxo1cQPomg3rK3umlLbO3N8lKcab3O4Dj+afdkbgZYmmhLnvpjcaVPAU3AcFEnZtnz7Vtj2Xmzl2sssQjjqQMyXGpLj6TjzO7clnaC6DHI6RgrE4l1R6pOZaeAroU2C0D6KwktmAE9iyyxjNUxXFOUJWhWuO8ehEjq1joMq6yEjCB20xV7ByUWW3ulcXPNa6DcBwHYoN83yLS/E09RuTKadru/3LyxZ5quNUqOriik9zXLJkUpAp4clBmicQ5vbUdoP15K4bACKrKGIYqOGuh7eHI6jw4rTaMCfLdzmmlMjp2HePrtUOdpY4Gmhr4Zrpb7sDhSme7mFWWq6GvGiUzQcJWKzik+CtBDmtcNDQ9xUW1xkMeeDSfAgrfY2yMJgERIa4kvcWsZHHvc97jQNB376quvnaZjepZmte7QzOb1Qf8A0o38PbeK5ZNatou1ZeeeK65Z5fF9MhFAC51Kjc2h0Nd45VSja73lkdkcO6jKjI7q6qyhuG0zsdaH1LK9aaV9GkgUwhzjWR2VKNqdFrhu4bxXkMiolOMezB+LlfdIqGWYk6KVHYnfWX5q3EDRqQ1brZG6BjJJY3ASEhmI4XEDMnDqBzoexZ+LKXpRZaeEPUyBFZKZk+A+JU6NhdkS48yoL7+jA6rDX63qutd9SPORLRwBVPDyT7VFpZsMFw7GNzWNBJa0nPIl/wAAtV3ztB/VMaDvBNfE1SyLe8esfgsoLwkLmgODakCoYDSpoTTfror/AKaVNWYvV4+6Z9U2KYSwQyDPFGx3HVornzUmJq03Hd/Q2aKE59GwMr7QGQcabzqe0lSDkn8T8qs5eReZ0Ld+2C1mQOs0obmTQmmZrTKhDt+qtmyyMj/SYXOq1oOINJJy4U1Fcs89MlMEfrHfovJj1SO7xWiM/ci/fx2f2vkvV79zHAIU2B8nvkyUdbXnLVTbluSa0YjGzEGa6c96XiM5HzyWNwWGjcWeJ3kAdFe222tgaGgB076BrdwxGgLuC0tnbDZjJGQ94FMqFse4k9o4JdsDHGVkjiS7pGvNdSQ4HNDlQ05rHHbHv/R1LZi5DEDI44pX5vf8BwaOCYuhUuGxUyUn7qoaYjdu2VbGEH4pJ+0+/ehjFmYf0koq872x6U7C45cgU77S3tHYoHTPzpk1u9zj6LR89wBXz3eVvfPK+aQ1fIcR4dgHAAUA5KFEs5cDBs9aS5nWJJBp2pusW5c2ue2dG/M9V2R7DuK6Lc0mQ4KKqR09Lk3R/Ax2EKc6zAa+id/ArVYWUFR1h9aH5qyhlaQd40IO7sIWyQ1uo23Y7E3P0gS0/iGR+B71RbWXyyykxsAfK7MN3MB9Z/mab15et7mzVbHQvcOqTmANA53aNO3LgkkWd8jiTVznZknMkn1ik9Vnilt9w8Fyf2IlvvCaejXuq0UOEZBzvbI9Z3adNBQLyO72t1oePDkeKt47EGZZV3nl2rRZqytEjY6Ql2HpXauzpVjfZrlU70mpzyek0WKMaRptUz34cRfI4dWNgqaVOTWDRoruCZdmNkeljbLaHFocMQjZTIVyxPNanXSixsN29HhkZXG9nQtqQSJHuwlw4ANLnfulOcRDaRtyDQK9gAo0c6J3T6ddz5K5LXRFsOz1mg6zIhiPol3WI4kV0PJIv2y+jZ+b/c3810ourn4Bc9+1+yl1njkGfRyCvJ4Ir/Fh8U9sSjSEc1uLOSlACELM5h6VJuq8H2eaOdgaXxPD2hwq0lprQjeFFqhAWdss325x0aJLG8H1yyRpA7WBwFeR8U/bJbU2W8Ig+F9HZ4oXFolbQkVc0E5GlajLNfKqkXfA+SRjIgTI5wDKZHFXI1GlNa7qKCbPsJzSsMAGmvFcpLrbZoYoopHzYWnG9zyS57tdTXCNBwouiRX/AANjb1jXCOrQkggaHdXvV1uuqKbossujKFT/AO8zfYf4t+aFemRuifJxNV0XZW5nzRYHVbC0+g3q9KcqufvcKmgB4eCHdEAknhjd6L5GNPJzgD5FfRN13cGNLaUON9R2l7nHzJWSQS5KqDZ5jo3RlvVe0tPek+y7NPitsNnePSkbRw0cwOq5w/dBqNy63FFRbw0VDqCo0NMxXWh7aKJ491Fsc9hjJHQrCR4AW6WYUSF9ou0whiMDD+llaRQHNjDkXHhXQd/BWfBMVbo559pO0n3u04GfqYSWtz9N3rP+A7M96UVnO6rjzWCqgfYJi2Zvt0ZwE1G6vuS6so5C0hw1BqENWi+LI4Ss7Ddt9MOdXMd2Zg8xvHbTvUu2XoTmKV3Oboew/LNKF3UcGuFcLgCCO3s3/WiYLDZiRWtamgIB91Tn+SUz6h4sbZ38UVI1x2N88nEk79P/AMhT5oo4WnrAAek8mgPKqt47I6Bpa4YSfS409lIW0jH2idrWhxhjpiAGVSd/HT3rlY4vLKn+5rKdK4ku1ua4Ne94jgcQAXGjpK6Bo1oeI3K7tVniZZxHHQ4mVZhzaWtLTkRXmONFlYWwytwlrX4eroCQRuNdFIiutow0aGhtcJjo2lcyC2lOBqPBdjFiUI1H3ITp2zfckJABcQTFVrRXLpD6ZPY0dXmXq5gb351JOrncT9ZKouWyCNjWAnq5Zkk13kniTmrR1oY0ekO7P3JqNQXJjkd9kpzwOfuSntla4XRugkq4vFcDWuc6gI69GgloBpmcqrXtRtG+JpETaE+s7M/utGp+qJOu6J4f00tpGK0s9AAyPIPoAgZjLEctDSvBXxzWR1Hr3Zz9RmWJfdi3fdyOgOWIscMTS4DMZaEE11HBVKaL9kOChkL3dI7JxrRricmgOdQZHUnLPLRLWA55FROKi6RzU75MEL0tXioSC6d9nVwdDH96lFJJRSMHVsZ1dzd7uZSnsXcQtEhkkH6CHN/7bvVjHPU9nNP1svMAOeTha0VJ4ADQDyWkI3yY5Z15UZ7UW973R2OBxbLN6Tgc44WnrO7K6DvVpJa2QxukeepGypJzNGjt1cfeUuXDGQHWiT9dPR1D6kf82zwoT3Ko+0S9SGMswPpfpH/hB6je81P7oVk+NxSraiav+J9o/oY0JHQqb5fIxtj8GVk9Nv4m+8L6kf8ArZPxleoVYgzYxehCFcqabRoVw3bv/qM34Y/cxeoWc+jbD6hKchCEFX2CEIQQPWyv8nj/AHv77l0LZj04/wAbP7wQhcvX/wBP5PQab6X/AJLTbD0pPrck3ZnR/wCL4BCFXTfXl+WXxfSiezfrzzHuCYrHoEIXRxdstPo8n1HM/wCFbDovUJTU/VYpPsTNpP1jeZ/ulVMf8rZ+L/5c6ELo6D6T/JyNb9X9im2x/lVp/GP/ABhVdi9N3I/BeoVp9mePpEJ314LBCFQk6Vsd/wBNb/77/cFr2p/kr+cf99qELePoFJfVL+f0z3e5c121/lknJn/jahCiXoL4/UUiEIWIwf/Z  " width="300px" height="300px" data-tilt data-tilt-genre>
              <h1 style="color: white" class="bottom-left">Pop</h1>
			</div>
	</a>
    <a href='http://soniasonec.temp.swtest.ru/app/genre/rap.php'>
            <div class="image">
              <img class="genre" src="   data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBw8PDQ8PDw0PDw8NDw0PDw8PDxAPDRUQFhEWFhURFxUYHSggGBolHRUWIjEhJiktLi4uFx8zODMtNygtLisBCgoKDQ0ODw0NDysZFRkrKys3LSsrKysrLSs3Kys3LSsrKysrKysrKysrKy0rKysrKysrKysrKysrKysrKysrK//AABEIAOIA3wMBIgACEQEDEQH/xAAcAAEAAgMBAQEAAAAAAAAAAAAAAQYCBQcEAwj/xABQEAABAwMBBAQIBwkPBQEAAAABAAIDBAURBgcSEyEUMUFhIlFxgZGSocIIU3KisbLBFTJCUmKCk6PRFiMkMzRDREVUY2SDlMPSJSdls9Mm/8QAFgEBAQEAAAAAAAAAAAAAAAAAAAEC/8QAFREBAQAAAAAAAAAAAAAAAAAAAAH/2gAMAwEAAhEDEQA/AOHIiIJymVCIJJUZREE5TKhEGWUysUQZZTKxRBllMrFEGRcmViiDLeQlYois95RlYoiJymVCIMt5MrFEVOUyoREZZU76wRARCiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgFFJUICIiAiIgIiICIiAihSgIiICIiAiIgFQiIJREQEREBERAREQS5QpKhAREQEREBERAKIiCFKIgIiICBEQEREEIilAChFKAiIgIiICFEQZOWKyesUURERBEW4pdM1ktvnuLISaSmkbHJJvNBDjjqb1kDebk/lDvwGnRbrR1hNyuVNQiTh9Ic4F+7vbrWsc9xx2nDSvjqezuoK+po3O3zTSuj38Y3m9bXY7Mgg470GrRfaWklYyOR8UjY5t7hSOY5sb904duuPJ2D14XxQQpREBERARFCCVCIgIpX1fSyNjZI6N7Y5C4RyFrhG4tOHBruo47cIPipVo2f6KlvM88UcohFPA6Yvc3fBdkBkeMjGcnn2bpVYLDnGDnOMduc9SCEWzv8Ap+rt8rYqyB0Ej42ytaXMdlhJAOWkjrB5dYWsQEREBQpUIPo/rWCzesEBe2y0PSaump8kdInghyOsb7w3PtXRNiGjKW5ur31kXEjhjjijG85oEku9l4IP3zQ0Y+Uq/s2t5bqWigePChq3hw/KiDyfaxB7Nsek6e1XGKOla5kE9OyQNc9zyHhzmu5nn2NPnK6HpCjH7hahmPDqKS6zhvadx7gD81q0HwhniV1snA/jGV0fd+9ytA+kq26YG7bLdSj72XTl2lI/Ke+mI+u5BzfYJTh9/jef5imqZB3EtEefQ8rw7bIt3UddywH9FeO/NNFk+nK2Ow4llZcZuyG0Vjs+J2/GR9Ur6bbqcPv8I/tFNQ/Oc5v2ILftfs7I9LW9jRzoHULe8AwFjs+UlpXGbNpusrYqmamgMsdFHxZ3AtG63meQJ8I4a44HPkV3TatUCS1X6If0Ka0jybwgPvry/B8gYLVUl4Gayukp25/CDKUPx5Mb6D8/ovT0GQ1HR2tL5TLwWtaObpN7dDQPGSvvfbJU0E7qerhdDM0NcWEtd4LhkODmkgjvB7D4kGvRFCCVClQgL0UFHJUTRwQxmSWZ7Y42N63OcQAOfIeVeyg09WVFNUVcNM+SnpMceUY3Wcs9pycDmcZwOZVo2I0nF1DSE9UIqJT5oXAe0hBULxaqiiqJKapiMU8JAewlrsZaHDm0kEEEHIPau27RrO1mi7e3AD6JltlcB2PkjLX57i6QnzKo7fGtddoKhn3lXQU0rT4/CePoDV0XaTiS2XulB/kdLZ3geICQu9woK98GiHwrnIRyxRMB78ykj6FzWkoc6hZT45fdVsOO7pW6fYul7CZOFbKmTtkuluh9MkY98qpWqnzrYsx97eqlw8jZ3uHsCCz/AAk4gZLbM3mC2tiLh42PZ4PpLlWtKaDhq9OXK5PLxPTGU0+HYjDIY2yPyO3ey4d2At/tkk4toppTz4d5vcOe7pc+PYwK1bK42nS8UBA/h0N3Plw9zPoQfnFFa9l2no7leKemnaXQYllnaHFpLGMJDcjmMu3Ry54JXz2lWBltvFVSxNIhYWPhDiXHhvY14GTzOCS3J/FQVhQpUIPvUROY9zHscx7CQ5jgWuBHWCDzBXWNeaBpaTTVHUxxhtZAKV1W8OcS7jN8IEZxyeW45dQ71rtsFubNfaV8YwLtT0EuR1F73cPI8war3rmqFTDqmkxltDTWl7B4sNMpx5N0INTsYn6NZ2yHANZe6anB8bd1gx6d5afRNBu66naRyhq7rIPkkS7p9DwvrapODp7TfZxb/HOezkyaRv0YW5sMO5rm7O+KpZ5vWjg5/PQVnabP0iw2Wp68z3VpPlnOB8xX2x5bXWSnd1/uXcxw7yIc/UXOL6d7RVqd2suNUz1jO5dBD9zWNrh7G2URY79yZx+qEHPtlAxQajk6iy0ytB8RcyTH1VtdpUXE1DYieqeltA8pNS7P0heHQjOHaNVO6gIYoR5S6YY9oW8vreNdNGyEc5aW2uP5rmP+1BstVPE0Ws2de4bY/HyIY/8A5qNmcnBtenscukXauce/+DVcf7PQvDHLxJ9cD+5ef0QmH2LG2z9FotFxZ5y1ssnmlnx/voK3oq3CTWnDLctguFwkORyHCMrmn1g32L37fHMnktdc0fyukkby8Ucm8B+tK22j4BHrS8PIwKeO4z+s9n/Mqta0PG0rp+c9cT66nJ/zCPbwgUFUsekK+upqiqpqcyQ0YJlcC0HIbvFrAeb3Ac8Du8YWooaOSeaOGFhklme2ONjetz3HAHpXddF3L7l0WmKbO6btVVM04xjebI10cYPnlh9RVnQFhEOtH0+7hlFPXvY3HLcDXiP2PaUFB1NpqrtlR0esi4chY2RuHB7HMORvNcOvmCPMvpqDSddb4qaWqpzEysZvxHLXdgO64A+C7BBwfH3HHTdVR/dqk05UkFxqK+oo5D2ljqjlnyNicfOVs9slWK20Vrh/Vd5jp2EAdQpmBw8m9KfQg2Gy6njZYaShe1u9eYrrK4fhOaPAz6pZ7Fz3YP4N0qpT1QWyrkJ8WHxj7VebZUGnu2k6Pqcy1TF47My0+T7YVVtn0DaeXVTwMCloq+Idw35MD9Wg+Ov4BNFpR55mehpIHd+6YgfrlXLUk3FqNYx/F263/Mp5H+8qzcGcWh0VJ14qeAf9TC0D5hW6D+LetXwn+dtr/mQNZ7yDV7NZDDYIX/H6kt7R5A+DP1SvhbqbG0Et/wAZUyemlfJ9q+dmeYtMWd2cb+pIH+Zu/wDa0Lc0VP8A9xZj8WHyH863tHvoNPrmTjaZL/i9RVw8z3VDveCuegXCGn01TdXSKK7SY+UWSe8VQp38XR1c7r4V8c/1gz/mrdapNyv0Wz/xtQ4/5lEMe0IKdsVhMFfdJyf5Dbazn4nB7efoY5fHboN64UVQByqrXSS57C7ekz7N30rY6OiEUOsXfF09TAPz3VDfsC+G0Cn6TS6UPW6po4qY56yWmFv0vKD76+2d0tDp+kq4muFXH0bpri97g7isyfBJw3Di0DAHLryuURROecNa5xAyQ0EnHVnkv0Jr6p6VT6oox1UEdplZ5mNkd9XCrmyK5w2mzVt1mZni1kVIORyWtjDuXnefV7kHtjounHRc7fCa0GGR3bvUwY8A/oZPQvjZK4Vl21dEOfSaOuDO8QkxNI9YLQ6D2mx223uppqV08tM+aa3yNLd1kkjHNcH5OQPCdzGc75C+OwyozfSx7smrpayIknJJIDznxnwCg9Wtp+jWjSjRyDI5ap3lL4ng/Od6Vd6im4WpdQVIOP8AoZf3ZMUQz+pVB22M4M1qof7DaqWNw/K5tPn8ALo+peTb7VfHadoeffJ0pvuhBzrgGfRNO0HnFegPWje36ZArlcJsbQaJv4lMYz56OY49oVc0HHxdLyx9e7frfgfKkpm/avdWT/8AcRpz1TQsH+gDceklBrqaMxad1TjkTcYIfMKpgI9DirDSx8Sr0Sf8HIP0dOw/YtPe28LT2oc8uLqKaMd+7Kw+6VYtHs4o0dMBnhR3eMnxBtO9v0tCCuaVkMtXrFucmWlupH6SUD6wWGppRGNFjq4cNHMfzpKd3urzbKZTJd703sqLfdD5SZmY+sV8Nr8/CrLMzqFNare4DxHffn2MCC4FhhvWr5wOcNsc4H8p9M149O6qZM01GiINzJdR3dzCAOeXscQP1rV0HW0QgZqmq7KmhtTAezwmvi+0Kq7FJaapoay3VEzIuHWUNxbvuaA5kUjHSDmerETQT2b6DX7Xa00d1tcEfVZ6KgDW/wB41295shrFeoqQRavuFW37yWyGsa7xZEcef1ZXFtoN5bX3etqmHMckxbEewxsAYwjyhoPnXX6e/Ur9LvuJmYKplofaHjI4nF+9YMdeSSHeR2UFP2bbQaKgoOj10Msr6KpfWUPDALTI6F0ZYTnl9845/K7l9bDLLX6YvgOHTz3OlnPWBxJp4snuGcrlRXXvg/zwONxpZ5GsEgoKpoc4NH8HmL3Hn2ZLM9yD26mr2s11b2NPg0ooaQc/x2O5H9KsYac08euXEdcm4090sk5x6HtVHrr42p1QK5pzG66U74z44mTMDD6rQul6/h6PbdUPHI1Fwt7AfGDFSvP13IPBpaLi2bS2efDvb2+iSZ+PmrHSkvG1XqMfj0l1hHlbPEz3SvZsqi41ntOP6LfZXHydFmP0vC1GzaXe1jcx8e67t9M+99iDw10nC0nYCeWbnNN5myyjKuscAbrmtk8dr43oiiZn2Kha+bw9M6cj/GbWyEeVzT766NWDGpq2bs/cy+TPfxWgfVKDnFgO9oq8Dtjr6ST1nwNyrXeKgQ6l0vD1CGgo2D/MEkePYFU9FN4mldQxdrXUMuO3lIHe4t3tCm4esLSB/MfciPzccn3kE1MZp7XrJ/a+5NhHkNVg+yVfS00pq7Xo9x5mG5yROP5DJ3Px6kK9W0KPg2fUAPLpF+iA78w08v7V7di9P0u00B7LZd6mR3yTRyYPrTt9CDw2io6Xf9VUYP8ALKOribjnl8QETcd/hFVfVA6PpCzU55PrKmpqyM9bW74HskYtNp/VwotQvuW6ZIn1VW6VjMZdDK529jPWRvBw8ZaFltM1XBcainZRxOioaCBtPTMeA12PwnYGcdTRjP4Pegp5W00re3W+4U1axgeaeTeLCcbzSC17c9mWkjK1RUILBrrUzrrcZqwx8Jrwxkce9vFsbGgAE45nrPnXadU1AGjelZBfVWqz0zvKHgH/ANjvQvzsrrctevn0/TWfhbpgkBfNvAtfE0udGzdxyOXD1B4+QXLYvDx7TWQA82XWzTeYVMLj7IytTUVYdrwPB/rOOLzgCM/Qtx8GuUcW5RH8JlHIB8h8nP0uaqKav/8AVGYHkb2ZM9xrc/QgvG0yMw2Krb/aNTV7/NmY+6FZdlTAbNZpf7M288/FmWT9q1HwgmcG30kXx1fWVB+cf9xbDZTWNbpGplP9DbdMHxfvfEP1kFD2CnevcjSf46iq2HvyWH7F8du0gN8MY/o9JSRfML/fXk2K1XD1FRZcA2TpERzyzvQP3R626vLtbq2zaguL2kECZkWRzGY4mRn2sKDqe1W6xO0rBMDl90ZbW953G8U+jdIX5+X2kq5XRsidK90cW9w43PcY2bxy7daThuTzOOtfBBKhFKCEREGTHlpDgcFpBB8RHUV3/bpcIvuJA6Ij/qtVT1B55zG2mHMeiL0r8/L0VFdNI2Nkk0kjIWlsTHvc5kbT1tYCcNHcEHefg8MElsmb8RcjN6aZrf2qkbJazf1a1+f4+S4ny70cjvsVg+DzdGxU93a9wAijhqQCee61soe7yDDPSqLsjm3NQ25x7Znt9eJ7ftQWPbRFwqOwQdsVFKSPlcL9iv8Acz4FbWt/D0lFuny8Z37FR/hGStFxo4W9UNE047nSvA+orpV4GkXVPY7T9HS57w0tI+ciKLsZi4tFfYMZ4lNSuA72uk/avHtVrC3V0j88qea3bvduxQu+klbL4Ocw+6VZA4ZEtEX93gTMGPn+xU/alU8W/XJ3iqXx/owI/dRXVvhCNEVtja046XcmzuA7d2lLCfYFzzZ/tDdaaKvphE6R1U0up3AgCOcsLC53jGN08vxe/Iw2la++7EdAxsLouiRO4u85pDp3BocW4/BG7yzz8I8lRUEqERBmQsVk5YoCIiDfaO1XU2mofUUvDL5IXwOErS5m64tOcAjmC0FaiGpc2ZswOXtkbJk9rg7e+lfBEHUNuWraW5SUApJhKyGGSR5bkAPlLfAOfwgGc/FlajTGu2UVhuVsMUjpa0v4LwW8JokY2OTeycjwW5GAck9ioyIAOOpQiICIiAiIgIilBCIpQZMkcM4cRvAtODjI8R8YXv07c+iV1LVYJ6NUQzEDGS1rwXNHlGQtcoQW7ahqmO7XR9VC17YWxxQxcQAPLWgkkgZx4TndqtlVrCmdohlDx2msL205hB/fAxlTxQ/H4u41oz1Z5LkqnKDe6M1RNaa1tXA1j3BkkbmSA7jmOHUcc+sA+Zamvq3zzyzyEF88kkryOQ33uLne0ledEBEUoIRSiDMrBZFYoCIiAiIgIiIIREQSoREBERBKKEQFKBEBERAREQQilEEKURAREQZFQhRBCIiAiIgIiIIRSoQEREBERARSoQFKhEBSoRBKhSiAiIgIiICIiCSoQogIiICIiAoREBERARFKCEREBFKIIUqFKCEUogKEUoIREQSEUIglFClAKIiAiIgKFKIIRSoQSoUoghFKhBKIiAihEBSiIChSoQEUqEBEUoIRSiCFKIgIiLQkIiKJRQiKqIiICFEUBQiKCUUIglQiIJCIiAiIgKERBKIiAslKLSVAWKIg/9k=  " width="300px" height="300px">
              <h1 style="color: white" class="bottom-left">Indie</h1>
			</div>
	</a>
    <a href='http://soniasonec.temp.swtest.ru/app/genre/rock.php'>
            <div class="image">
              <img class="genre" src="   data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMTEhUSEhMVFRUWFxgYGBcXFxcWFRcYGBcXGRUXFhcYHiggGBolHRUWITEhJSkrLi4uFx8zODMtNygtLisBCgoKDg0OGxAQGy0lICYzNzAtNS8tLy0tLjcuNi8rLS0yNTUvLS0yLS0wKysuLS0rLS0tLS01LS0tLS0tLSs1Lf/AABEIAOEA4QMBIgACEQEDEQH/xAAcAAAABwEBAAAAAAAAAAAAAAAAAQMEBQYHAgj/xABPEAACAAQDBAYECQgFDQEBAAABAgADBBESITEFBkFRBxMiYXGRMoGhsRQjMzRScnOywSRCgoOSwtHwNVRis+EVFyVDRFNjZHSio9Lx4hb/xAAaAQEAAgMBAAAAAAAAAAAAAAAAAwQBAgUG/8QAMREBAAICAQIDBQYHAQAAAAAAAAECAxEEEiEFMUETUWGBoSIyQpHB8BQ0UnFy0eEj/9oADAMBAAIRAxEAPwCdIgoMuAM7AczpAJGWYz07/DnAFaOY6xjLMd2YztrBdYtr4ha+txbzgOSIMCDcgakecAOtr4hbncWgOgIMiAsxToy5941gNOXXEtvEcNYDgiOLQq7C17i3A3yzjgsNLi+uov3mAAEGBAxrzGhOo0Gpg0dToQfA3gBaDAg7R0IAgI6wxyXAzJAtrc2tEVW7zU8tcWIuM/QVmBtrYgWgJi0dBYri77UZUP1hAJAzFjnxK62BIEcTd71xsklVfCL4i+EN3KADc+UBZsMdARCbE3nkz0xXwNa5VjnbmOYh7I21IY2WYhPcyk+QN4CQAjtRHIYa8Nb8LQqsAUdCBBgQBgR0IICOhAGIUWORCiwAg4FoEBUN4x+TTPAfeEIbTNpVO30XQ3/Rh7t+XenmAWuQALkAekOJhntLBMpurR0LhVNg6/m2vxy4wETsybmp/wB2s9/NRb3wnKypHQ/mzZZ/aAOkOzR267CVPWoqS+0vaJwhwM+dxCM+lIE2WHViTKtd0Bup7S2vla9vVAON6pmF5ZGvVuPPKJOfRp8EwkXCy7j6wQkHzMMdq07zOraaglgLMXN1te3YzJ4w+p3xUhBZbiUVPaWwIBAu17C+UBEqElpSPawJZmIubnCovDeUUwSC4xJ1s0kWJuMtB5RJSJWIUqqUJlYi4DKcIsMznnDWlVgJbJgdpMyYzATEyBta5vlASG8UsLJlhRZRMSw7rG0JbZH5Qv2Ez96FdrzxOlIEKGZjVsAmKTliuAb58IR2gHLLNmKJY6p0OJ1sCcWEXJ4wEXRvdVU6rJnj1MuJffE3uysvqgyLZrAObWxHX1jOI9KIgLMuuE05QnEtuswlQL3tcxKbvT2KdWVUBFABDhr3vqBppASl+cU3e/et5REmnWztrMK3AHNRx4jPvib3q20tLJLEXZgQg5m2pvwEY4s9iGnO1yx1/OJ1I17zlALbQ2xOe+OomMb6YjbxsMreqGIqJmZxMM+ZA7/Pj4wjKAzLMByFr/8AyOMeRt6/58oBeXPzt33vYcjf3wlKnFT2SR7Pd4QQXmbHLKCmgnO0Av8ACGCghiLWFrWv6+OsIzJrXxMSWOeK+fnBu+QxDhYQjrATNDtmqlj4uomqoPCawGWeSk2ixbt9I9RKcLUEzpZ1vYOvMggdrwMUVDaFgBi1sCb/APyA9BbI3npak4ZM4M1r4TdT3gYtSOQiZtHmmRVPKa6MykEEFciLHIj+eJi00PSTWIwLus1bC6lbeRGhgNuAjoCM/wBj9KNO7BJ6NKvbtjNATwYaqO/OL7S1CTFDy2V1OjKQQfWMoBYR2sc2jpYDq0CDtAgK5tGglzpZlzVxIbEjMZqbjTvEUXdugl/Baubh7adYinPJSgJFtI0QiKLuz8xrfrzPuCAi5DKV2aAQSJpuMri89bX5Q/2FRU8ytqhPVCwm/FhiQcWN72sczkIi6OkRTQTAO1Mm9o31wzlAy4RM7typJrappuDEsy8ssbEMXe+G5zMA76SR+TL9oPutEIJaqNorKsJQlJYDNb4k078zE70lfNlt/vB91ohLBBtGVL+TEtSFBuoOJMx5nygJHZWzZLUDvIC/CDJIcqTjzNyCL5Xw+yON1tjS5wlTkwhBKeVUJmGdmxZ+BBUxIbvVUimouvVVMzAGmKrDG2EkC44WxQ22TMWVtBeq+SqpQmFAQcBILWNuRB/agEd2NkyfhtSMHyLKZeZ7JuRzz9d4X3wlh6yjlPmjHNeBu4B9gtC+7Hz+u+sPvNCW9JtX0ROQ5nT04CtofyGpXgtQlhwHpfwi9btUlOkoNICgsq9YVJN2A455HtaRRV+ZVR/5hPe0aFsCilypKdWoXEFZu9sK5+MBROkioWZMRAwLSy+Jb2GHI2J5m0UOprGP5oAGluBHHLIm3HwiW3hx/CHV8nlsRYjI3ZmB8mHjrETUAlddNATpzFuEAxJjpW9sGmsOyZeG4tewFjrfiYBmNbmFZs02GeXLlCpRSht+awzzzByP8fOGrd0AZbTOOlXW3D3RzbKCvABnubx0X/nxjiCgFB3wWLMGOSY6Qi+f88oA3PfE9uhvVOoZgZSWlE9uVfJhxI5N3xEU5w6qCW0va3frCDHwgPTuydpyqmUs6S2JG48RzBHA84eiMM6JdutJrBIJPVz+yRfJXtdGHflY+I5RukAcFHVoEBD3itbZaRRSSFk4knOQyhytyVNySQeCjSLERFV6RfkJX2v7jRpktMVmYWuFjrkz1pbylzUzKSXS089pOnakywxJVicR7V8xcDMiIvZlbRT5462mCO73DiYzDGTfPS2cN95Pm1F9kfwjveRAtTT4QB2JOgtncZ5RXnLbe3Vx8HBNNTHed6+Gk7t/acp6haObIMwYks2PDYsBY2AvlfnCNPMpUqH2etMAsxgjtjPa7OIXFr27rwx29/SifWk+5YMf0x+tH91GfaW382scLD0xOvwb+Z5sp6Rat6ZaUKWxSy5csGFgSMJ52hzsRaaVXPTyafAy4h1hctlkSApBtrzis1tT1W0GmfRnXPhcA+yJ/Zp/0xO/T9yRiMtt6+LOTgYor1a/Bv59i27W1ZMypmhJHVTHBZmx4seBtLWy1vCVftOTVCekymx/BwzDt2JsbGxAuuXuit7u1HV1stucwqfBiQffE5utKxVdWp0YOD63I/GM1y2n8zPwMOObTrtqJ+uitHOpXoZp6i0uW1zLxklmFrEvrc343tE1u5tAT5WIS+rUHAoxYrhQATew5+yM/p6rq6eokHUtLFvqscX3RGibt0vV00pbZ4bnxbMxviva0oObxcWGkzEd5nt/bSE3v3bE5lnoLupuRewNra/sj2xQJ2zZjCxBwYjkM+ORPMjT1RtrLcWivTNlOcFMiqMZwlhkQNcrd1zc8onchl+yt0p9TcyZbFBcYtBccQOIhDam606TiDrmoubcr2W45nKPTtBsdJMtJcpAoUAX49/jHFbsWU2stSbgi6gm401gPKE9GGTZaZc4bER6E3g6PZE0s4RQ511F/IxQNq9HboSVIA8//hgM7Vbwp8Ga17ZCLlS7p2viOfDK1vVD/wDyIoAFtOMBnnVE8I5KWi6bQ2N2SwFreMVatp8Jzy7uMAytBR3aCJzvALyQSL2PZ4+vK94KdrqDxuOfGFJLXvkgvxN8vC2XshOce7M+Nx7oB1sKdgqZL3thmof+4Xj0+DxGhjykDyj0vuhtAVFFTzQQS0tQ1uDL2WHmDAS9oEHAgICqqElqXmMFUWuSbAXNh7YqW/dSkynlPLYOpmntA3GSsDEpvsCaKbb/AIZ9XWLn74pdVVIaGTKDAus52K8QCGsT3ZiK2a/nV2fDONEzXN33vX0L7yfNqL7I/hCu9Hzmn+zk+8QnvKp+C0WX+qPtsR7I523VJNqZBlsGAWSuXMEXHjEM+vydLF5Vn/ItvYG/yh8XfH8Vhtriwi1oT2IswbRl9ffrcfbvYm+A8u60O9vH/SifWkfuwY/pn9aP7qMzH2t/Erk/8Yrr8EmG0aTrKis5qHcfokX9kP8AdCp6yvx/SQ38cKA+0GHOxZQfaNSh0ZZgPrwiGO48krXYD+aJg8iBGIj7UT8S194b1n0rH1iETIkdmdOGsqYjeouwPtwxYdxZuOpnv9Jb+bw13VpusWtl/SS3rxOR7QI76Oflpv2Y+9GccatDXlXi2HJX1iI+ujDbuz/y9pYyEyap9Uwgt7S0acFtl6vUIoG3f6Ul/Wk+8Rfonwx3t/dy/EbzbHi3/S6EOt15WOpZyPk07J73uCfIGGsTG5lKAkyYPz39ii3vv5xO5SzWhKYI7MctANZwyzivbVljO4y4xOVDGIPaehgKdVILkgNryhlgB4ZxN1aE39kNZsmwB5+zugIWtkHCbD8fXGcbalkORa3jGmV8ywNte+M+2/V3YkC19crwFdZDzjnFwjp5mccXgFZmVoJQTnnbn/iY4docU4BBuDYC/pAD2j2QCZXPsg93ON46HakPs5VGsubMU+s4wfDtxh7TNWVQqgWAzJ8T/No17oNa9LP0ynX7+1LX2dmA0m0CDt4+UFAQE6UrAqwupBBB0IOoimbS2Ts+mf4xnJ16oHF4YuQ8TFyq52BHf6Klv2ReMilh580Am7zGGZPFjxitntEajTs+E4bX6rdUxWPPS9HbNFWASHutyMOIYc+AVhkDwzh5szdSRJcTBiZhpiNwPAc/GKHt/Yr0rhGYNiW4K3GhscjpnGk7vVRmU0qY2uEX77XH4RjHPVOrR3hvzMfsMUWwXnot8Vf2nU7P+EmZMeYJqML2DYbppwsdIk6DZdNOmitllixa4N7C4GE9kxm9fMxTXbm7H2mNE3Ae9Lb6LsPUbH8YxivFr6mEnN404OPF62n0jz9JOXoqalmPVuxUtcElrgk2uFXnlwiCpdt0CVLT1E4MxN2Iuva1OEG8R2/lYz1JQ+jLAAHC5zJhtUbuOlIlWXWzWOCxuAx7JxcTpl3xre871WPJNx+JT2dbZ7zu/b/ULzsPZMiVimyGLCYBc4sQNiTl6yYhaHaGz6ebMZHcOxIa6sRfFc2y53gujeqJWbKOarhZe7FcEey8Uqt+Vf67feMbWyarExCLFwpvmyY8lp9Pn7ttD27S0kualVPLhsS4bXIumYyAiT2XtiTUYupYtgte6lfSvbXwMV/pG+Sk/XP3YS6NB84/V/vxvF9ZOmPVWtxovwvbWmZmO0fmusWbdVLU0sHUDPxuYq9TNwIzW9EE+UI7M6QqaSqpOLIb4c8xe/G0WHHaKYIiI3Z+2Jc4YpbBh3G4hzMqgBcwCVSh5xA1qZE3hfaW8MhAcUxR4kX8opW2N/aYGyti8ICTmi5OfuiOrJwA/n3RBvvXLNioNoVTa1PMHpEHkeEA12jPxXBHrij7bk3FwbmL3WSlI7JuIrVdSDu48oCiuI5Ah/tBBiNoYQHQ74c0yqVINsXC5Od+NtMoaiHSqCgVVu5PLPkFHvgEsr3sSOHD3RtPQan5HPNtZ9v/ABpf3xlNVsSqSV1ryJnV8WtdR3kA5eJjVOhCr/JZkoqRaaWDW7JBVbgnmCPaIDSsX85QUH5+z+ECArG2R8RO+zf7pjLd3vnMj7RffGp7Y+QnfZv90xlm7/zmT9ovvipyPvVeh8I/l8v79Fk6RJDtNlFUZhgPoqT+dxsIn93rpQKSCCEc2IsRrwMToMRm803DSz2/sEeeQ98SzSKzN3PjlTlx4+P0+UsnlSywY8hc+cXvo1m3lzV5OD5r/hFV2NJvKqj9GUPviJvo1m2mzU5oD+yf/wBRVw9rw73iX2+Pkj3aMt/KYrVsx0dVYe4+0RObJlms2aJCsodGCknSysSpy/skD1RI777I6+RjUduVdhzKn0x7AfVFK3V2v8Gngn5N+y/hfJvV/GN7R0ZJ35Sr4rTyeHWafep+i5bpbvzKVphdlbGFAw3ysTe9/GM5rvlZn2jfeMbVGK1vysz67feMZ5FYrERDXwnNfNkyXv5zELr0jD4qT9c/dhLo0/2j9X+/EFt7eJ6pVV0VcJuCpJ4W4xO9Gn+0fq/34xW0WyxMM58NsPh9qX8/+wu5EVTeWi2OoHXyXmTM7iUz9nhicIbJw1i2R1Q7NSY7KUUh1YMLWDAjQ2i68yqe7E+RIAejaZ1ZNijEuO8XOYMXLeecwpi66Ml/URpHVBsCTIk9RKlPhxsxLHO7WvmczoIG/U1ZVJh0slhx4QHnva5MyaS7k3PflFr3d3Bp5y3aoa/JdPC519UV+lp1abiZcSg3I5jjGgTtwZFQrTFmMswreXiAwKdQFtoMoCpbf3XlyMknHLhoPXfjEAs1kyVyDFynblT5cj46qGK57ONnUDK2ZHcdOcUqZslusKoS9jqBbyvAS1JtaZ6L5+qxgVc42v3GH1Hu+4tiBJhas2YcNjrAUSp4wxMS+1aQobEREGAAEO6SaUII9LgTwjgU7DUEeMdy+dsoCzbH3lqVYKZpZDk0shSjA6gi2mvnGodHGwJUhJk1A12mNhuxw4CFIAXS4va/dGO7Nk3mqvfHoDdik6unXW7AMc+4D1ZAQErg8PKBHXqgQFZ2x8hO+zf7pjLN3/nMn7RffGqbY+Qm/Zv90xlewPnMn7RPfFTkfeq9D4R/L5P36NN2vt6TTMqzSwLAkWUtobHSIne7aCzKDHLJwzGQC4sfSJOX6MRHSQR10r6h+9CG15n+jaReJcn9kN/7Rm+SZ6oacbhUiMOSN7me/wBXG7aA0tbe1+rAGfifwguj+barA+kjj3MPuxC02z5sxS0uU7qLglVJAtmbkd0Pd05uGskH+3b9oFfxivWZ3V1s2KJx5tTvceXu1DXlB5RlW+WyPg9QbfJzLuvd9JfUfYRBb31MwVc4B3AvkAzAeiNADFo3+lBqSW51UpY88S5+MT5LRkiY9zm8LFbiZMdt7i51uRtLrqcKxu0o4DzI/NPl7ozWu+VmfXf7xi2dGjHrZw4YFPrDH+Jip13ysz67feMR5J6sdVziYoxcrLWPLtP6rDvdu/KpkltLLksxBxEEaXysBEh0af6/9X+/C3SP8lJ+ufuwh0af7R+r/fjeKxGaIhVvktk8Nta877/rC8RJbvD439E/hEaId7Km4ZqnmbecXHm1maXmOUZ30s1l1wd40jRpxspbkIybfejmzixQXP4QFF2SQJgGucbFsJrIBa6cO6/C8YxOpp1NhmTEYLcai3GNe3YrVmyEdDdSIBztPZcmbqp8yIj6PdmUhLBAO+LCCDDSvqwo84CH2sETTh5xVJ8wE6Q523X3bI/zwivtOJ7jAM9vbKM0Apr7/CENg7l2dZk9gQDcIOJGYueXdE7JOUOaedZhn/CAgN6nVCxZVtktuJuDa3vippJawBFhkc8onNvV2KoZbAgPxzzCgDyz84ml2PKqpaulxOAAwWv1ncOTQCG5GxzPqFysCfJR6THutl4sI3FFAAA0GQ8IgNz93/gsu72M1wMVtFA0QHu498WAGAOCg7iCgIZ1BBB0II84ynbmwJtO5GEsl7q6gkW4XtmCPwjV4K0RZMcXhd4XNtxrTrvE+jIKWhnVDgKHdjlia9hwuzHgIsW+dCyJTSZaswloc1UnMkcvCL9YcIEaRx41MbW8ni9rZK26e0eiu7kUxWjsylSzTDYgg/RBsfCKHs2jmrNlt1Uzsuh9BrZMO6NevAUxm2GJiPgjxeJ2pa89O+pSN/NgzDMNRLUsrDtgC5UjK9uIItFXebPmBZTGa4XJU7RtwGUbGkGRGtuPudxKXj+MTjpFbVideStbl7Eanls8zKZMtcfRUXsD353PqigVlDNMx7Spnptngb6RtwjYTHN42tgiYiPciw+KXx5L5Jjc2VPpCkM8qVhVm7ZOQJI7Ns7Q36O6d06/ErLfq7YgRpjva+uoi5wnOnKqlnYKo1JNgI29lHX1Iv4+f4acGvn89lRHStbPl+EUnbXSJIlgrIHXMOOiD16n1Rnu197qqouJk2y/QTsL7Mz6zEqg9NbQrwJOLLCVuDwzjEd4N+irsssXsTGldEO0xU7Mlq1mMkmSwNj6NipIPNWEDebcelmpMKyJaMM1KgL52gMV2pvNNqZXVEXxEZccsxF/6L6WZKkYZmV2JAjug3MlyO1a543iWpHCgWyEBLT6q0VvbO0LXF4X2ntBbXB1y1tFM2nXYrjj/OkAVS97mGTT845nz7LaGAqM7c4CckPyhVJmE58IjJU4gwrUzwVN+Nx7IBgNgGYgnJNAeZdmVwbDEbqQRplziX2btSXsqZLmzVaezgr2bLgHEqDqeGcNKCpu4XhkB6tPdDTeuSsyrkSpjdWrS7BjorMzBS39m4W/deA17YG+VHV/IzRi+g/Yceo6+oxPx5VrKaZJmtLcFJktirDQhlNjmPfFz3V6Tqmmsk8mold+UxfqtxHcYDeLQIzv/PBR/wC6nf8Ab/GBAWuBHUEBAAwAIOCgCgAR0IMCA7ECOSYAaADRwYhtu70SKe4JLv8AQXM+s6CM53g3qqai4LCVLP5inMj+03GAuu299pEktLlnrJg5egPFuJ7hFH2ttudVZTG7PBBkvlx8TEAqZ4mNuAhu9cVPZgGzXRyDCZ5iHlawmIHHpDWI5WzgNW6CtsBZ82lZsInKrJ9eXe48Sp9ka7temqXUCVNUWvkwJvxAJByjy1syueRNSfLNmlsrjxB09enrj1TLlirkyp0piquiupB1VgDY+71QFF2pU7RW+NZUw8lv7yBEDSbUqsXxkgBScz1iZeAvpGi7V3Zx6sx5nEc4rVZu+ks3waZwFc2orDQ3RgTfyt7zFXqJ1mseMWfb9aQthkBoP8PCKLWVF2vAPqmaLRGvVkQlPn98MJkzOAmKasIh8s+4v74htnSyx7omKhb2A0GUBI7JljGCIYdJS/GyTzlfvtEvsEaX14xXekKrD1eEHKWir6yMR+97IA9+VDtT1QLFqmQjvcZdYgCNY8fRB9cVeLP1cyo2ZdQCtFNOI37QSfbDlyxg+FxFZIgCgoECA9PwBAgoA7wUAwV4DoR0DHAjo6QHMVHe/bkxSZMkkEAYiNcx6IPDKLbeMa3jryKuYxYqW7SjgQTZR5QEetZicq/E8eEIV1MVNxmITqku2I28RoeZtC+y6u/Yb1XgIx51soYvrD7asvC5Ahk0AvTPwhu4sYNGgphgO5Jj0X0RbwI9AJFxjp+yRfPCxLKR3ZkeqPOKGJWh2vNp3E6Q5RhkeTDiGGhEB6onV4IuCIpm8O8CAMNYqu8W886mlU02V25dRIWZ2xY4jcOFI0FxoecUDaG2pk+7aHle9oCU3k20rHL/AA5RU5lQSbxP7pvRu5l1adsnszCxwfVI4HkYtldulTkdhFHhAZgWMGi3MWraW6xQFl0EQclFRu1ATextnm2eQh+Kax5wjQ7TUL6rQ+o3xm5gFUmiUpmNkACTGc11SZkx5h1ZifMxZ9+K+xWQp73/AHR7LxUYC69HYlzkraF73qKfFLsDlNp8UxTl3YvGIHYGxjVGaiH4xZTTEX6eDNxfnhuRCm521xSVkioYXVH7Y5owKuLceyTE1Ol9XtZeqWy9aSAnGW7E9m+oKPoO/ugKTAjZv8zb/wBapv2JkCAu5MGIK0GIA4K0EYMQAAg4O0cmAQrXwozcgYyPeGm+Ey+sQdpGZcuIBtGjb77QEmimvxsFHeWNhGV7r7WFzLb84k+esBByKjKx4DyhWWbMGHAjLnz9UK7x0HVTMS+i0Ryz88Q9Y/hAKVz4iSeJMNFaFZrQgYA2gXgcIKAAi8707uCVs3Z9UksATJbda3FpjMWS/wCjlFGEbBtySk7duncTg7U5l6G1sXZMtlB9JcVrnlfjARm3UmTNibNmOAAjTpQ0zHpIb65qpy7ooeG0aTuyBV7v1EubNsaKcZiCw06uyKeNiWcX1yjOpg4QEdO1ixbB3smybIxxoNMWZHrivzxCIgNMrt55c6QwUWe2moigTsRNzeEUmkaQqKi+sArTsRxiaptpCUuI+oczEIH4w3qJpMBzV1DTHLsbljcwjF26N915NW02bVvgkSgLsXCLc5m7XvkovlxI5xeq7d7YIRJC4VabYSZrTvlboGDBgxwLc4bsoGIWgMRES9DaeuF2OOWgCEWBIU3AJOtr+Vo0rbnQ+HcGhnS1UL2kmOXIPDNQbZa+yMx2zsSopJhSfKeWwYqCQcLFdcDaMPCAcf5drv6zP/aaBEf10/8A4nkYEB6QEAwV46gOYEdGOTAdAxzBwDAUvpLbHJWVwviJ4aZRjqky35EH8YuW9m0eunzHN2XEQtycIC5ZDThFWr0xDH5wE9WTBPkE6kZxU3WxiX2HWWbCdDl5xG1yYZjA8z/hAJXgjBQIACBAgQAEbN0cOr7Eq0aS0zq+smFMOU0YDkrEdxzGYtlGMiNx6IaqbM2dPUuosHlSrC7qCrMbgkBs2yBt4wED0FhGm1ctpucyRgWSdJuTktbiVw93pmKLVyWRyjghlJUg5EEagjhE7uGr022pEuW6MUntKxX7Lrmpz7wPOOOkGSU2lVqxuROYk6XvZh7GEBWKhYQWSxUsFJUWBaxwgnS50F4tuxdzKqqMjBKYS57lFmn0AVUs5NjewVWz42tGpzt3aTZdBMkzGafJch5xZ+rIx/F3CopOFsIXPS2RBJgMJpdlz3GJJTstmbEFOEhQS1jobWOnKGZEa7O6XJKGbLk0wWUiBafCFsCoIGJGyCXw2AzsO/LKto1fWzXmYFTGxYolwgJzOEHQX4QCSzLRxYnOOTDqXWFZbItxjtjzyYD0QR3QALsyCWBdUxPkNMWHESeXYUQlLS44RL7OqcMmZLlnOatnY5HCNVXuhKjpCJeIi49K3GA72Pt+opVdJTBQ+eaglWwsmNCfRbC7C/fGmbA2zL23SNTV6lXpwrCej2Y5MocrY2sL3v2TlpGUBHmsuFTmTkOQOefCJGto5koTji0wqpWct8NxiUqjZjPiIDUf819X/XU/Yb/2gRlf/wDY1v8AWZnn/hAgN+gxAgxAFAg4KAMw22jNwypjfRRj5KSIcxA781olUc2/54wD9LX2XgMgpKu4CPpbK/4R1UUFuyNGHthjPXloM4drWnq101I8oCDzU94hzX9u0zmAD4iFtpyb9sc9Ia0s3IqdDANoEGy2goAQIECAMRsnQzUSXp50kSyWHytxdHxEhTy0ytaMbEaz0N0c1UmOcPVTwQCD20aWbXItoS1vUIChbWpzSVzAoyKk7Go0PVh7qV7rDKLd0oUIfaZanDTOvlSZxtmAZgwjPgtghvoLxUd8a6bMqnE4IGk/EgIuFMMsnDYXOuuvGPQG7NM86plbQCKtPM2dIUrbExcM7YVtyB5Z3A4QEft3bP8AkKgk0y3nVBRgjlbS1Nzi7XIFjZdTxjCK/bVRNBlzKia6Fy5VnYpjOZbDe1734cYnN/8Ae+dXTnBZjJWbMMpSACqk2F+N7AZHTSKgD3cYA5yWNvKBNl4YfVdMRLVuOvqhCpkkIrE93sgGl4ECCgJDZBszH+wc9QPGJ2mp5rSrqouV9HK9s7Efwit000ri7xaNA3IpuvfreGQNwQOznb8LiAqNPsua9PMcqVCOhxOcIwtiDZtrYhdPpR21HLE4AzUYTABZAxIxKLXLAAZ8iYm66UJM2rlTy058DsZeIhFUTEmLZtb2A0sNbxCTtqG8p0kSQQLAYCTiQ5DM55YYBn8CHJ/Z/CBGj/Cf+W/8Z/hAgNFhuvyp+ovvgQIByIIwIEB1FJ6U/m8r7X8DBwIDKD6PnAP4/hBwIBaq0iHTWBAgDnaxxAgQAgQIEABGr9EHyE37eV/eS4ECAz3ej53Ufav96PTnR3/RNH/06e+BAgPMW8Xzuo+3m/3jQzfTygoEBNV/yA+rEfU/IS/XAgQEcYKBAgOhGvdGfzOV9q3vMCBAV7er+kK7/pm+5Lic6NPQkfaTPuJBwIDVoECBAf/Z   " width="300px" height="300px">
              <h1 style="color: white" class="bottom-left">Country</h1>
			</div>
	</a>
			</div>
        </div>

    </div>
    <br>
    </div>
        
    </div>
        <script>
            if(window.innerWidth < 700){
                document.getElementById('co').style = 'display: grid; grid-template-columns: repeat(1, 290px); grid-row-gap: 60px; grid-column-gap: 80px; justify-content: center; align-content: center;';

                }
            if(window.innerWidth < 1100){
                document.getElementById('co').style = 'display: grid; grid-template-columns: repeat(3, 190px); grid-row-gap: 60px; grid-column-gap: 80px; justify-content: center; align-content: center;';
                }
        </script>

  </body>
</html>