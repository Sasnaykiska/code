<?php
 $servername = "localhost";
            $username = "soniasonec";
            $password = "spve_if4nShqj5xc";
            $dbname = "soniasonec";
            
            // Create connection
            $conn = new mysqli($servername, $username, $password, $dbname);
            // Check connection
            if ($conn->connect_error) {
              die("Connection failed: " . $conn->connect_error);
            }
$name = $_POST['name'];
$sql = $conn->query("SELECT * FROM songs WHERE author like '%$name%' or name like '%$name%'");
		if ($sql->num_rows > 0) {
			while($data = $sql->fetch_array()){
    $ID = $data["id"];
    $postName = $data["name"];
    $postAuthor = $data["author"];
    $postImage = $data["image"];
    $postColor = $data["imageColor"];
    $postMusic = $data["music"];
    echo  "
    <br>
    <div class='music-player' id='play'>
        <img src='http://soniasonec.temp.swtest.ru/images/$postImage.jpg' id='img' class='cover' style='border-radius: 10px;'>
            <div class='info'>
                <h1>$postName</h1>
                <h3>$postAuthor</h3>
                <audio controls='controls' id='audio' style='width:100%; '>
                    <source src='http://soniasonec.temp.swtest.ru/music/$postMusic.mp3'>
                    </audio>
            </div>
    
        </div>
    
    ";
			}
		}
    





?>