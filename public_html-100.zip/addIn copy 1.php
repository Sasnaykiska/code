<?php
$link = $_POST["link"];
$id = $_POST["id"];
$conn = new PDO('mysql:host=localhost;dbname=soniasonec', 'soniasonec', 'spve_if4nShqj5xc');
$sql = $conn->prepare("INSERT INTO `play_songs` (`song_id`, `playlist_link`) VALUES (:id, :link);");
$sql->execute(array(
        ':link' => $link,
        ':id' => $id
    ));