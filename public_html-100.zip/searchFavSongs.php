<?php   
    //Подключается к базы денных
 $servername = "localhost";
            $username = "soniasonec";
            $password = "spve_if4nShqj5xc";
            $dbname = "soniasonec";
            
            // Create connection
            $conn = new mysqli($servername, $username, $password, $dbname);
            // Check connection
            if ($conn->connect_error) {
              die("Connection failed: " . $conn->connect_error);
            }
  
  //Принимает значения из строки поиска
   $name = $_POST['name'];
   $login = $_COOKIE["login"];
  //Выполняет SQL запрос где ищет значение из строки поиска по названию, режиссеру, году, жанру и возрастному рейтингу, присоединят вторую таблицу ages и берет из нее данные для определеения возрастного рейтинга
   //$sql = "SELECT * FROM `songs` WHERE id NOT IN ( SELECT id FROM songs JOIN fav ON id = songid WHERE userLogin = :login) AND author like '%$name%'  or name like '%$name%';;";  
   //SELECT * FROM `songs` WHERE id NOT IN ( SELECT id FROM songs JOIN fav ON id = songid WHERE userLogin = 'asd') AND author like '%OG Buda%' or name like '%OG Buda%';
   $sql = "SELECT * FROM `songs` WHERE id NOT IN ( SELECT id FROM songs JOIN fav ON id = songid WHERE userLogin = '$login') AND author like '%$name%' or name like '%$name%';;";  
   $query = mysqli_query($conn,$sql);
   $data='';
   while($row = mysqli_fetch_assoc($query)){
        $postid = $row["id"];
    $postName = $row["name"];
    $postAuthor = $row["author"];
    $postMusic = $row["music"];   
     
       $data .= "
    <div class='d-flex justify-content-between'>
            <div style = 'padding:10px; border-radius: 10px; backdrop-filter: blur(30px); width: 100%; margin: 10px; -webkit-backdrop-filter: blur(30px);' id='$postid'>
                <div id='$postid'>
                <h1>$postName</h1>
                <h2>$postAuthor</h2>
                </div>
            </div>
        </div>
         <script>
        $( '#$postid' ).click(function() {
        $( '#$postid' ).slideUp();
        $.post( 'test.php', { login: '$login', id: '$postid' } );
        });
        </script>
    ";
   }
    echo $data;
 ?>