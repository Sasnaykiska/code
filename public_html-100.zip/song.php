<!DOCTYPE html>
<html lang="en">
  <head>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous"> 
    <link rel = "icon" href = "logo.png" type = "image/x-icon">
	<link rel="icon" href="wave.ico" type="image/icon type">
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Waves</title>
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css"/>
   <script src="/js/bg.js" defer></script>
   <script src="wave.js"></script>
   	<script>
	window.onload = function () {
	    document.body.classList.add('loaded_hiding');
	    window.setTimeout(function () {
	      document.body.classList.add('loaded');
	      document.body.classList.remove('loaded_hiding');
	    }, 500);
	  }
	  function onlyPlayOneIn(container) {
	  container.addEventListener("play", function(event) {
	  audio_elements = container.getElementsByTagName("audio")
	    for(i=0; i < audio_elements.length; i++) {
	      audio_element = audio_elements[i];
	      if (audio_element !== event.target) {
	        audio_element.pause();
	      }
	    }
	  }, true);
	}
	
	document.addEventListener("DOMContentLoaded", function() {
	  onlyPlayOneIn(document.body);
	});
	</script>
   <style>
   @media screen and (max-width: 1000px) {
        body{
        background-image: url("http://soniasonec.temp.swtest.ru/phone2.jpg");
    }

    }
   
   
   @media screen and (min-width: 1000px) {
          body{
        background-image: url("http://soniasonec.temp.swtest.ru/phone2.jpg");
    }
      .nav-links{
        margin: auto;
      }
    }
    ::-webkit-scrollbar {
      width: 15px;
    }
    ::-webkit-scrollbar-track {
      border-radius: 10px;
    }
    ::-webkit-scrollbar-thumb {
      background: #bcbcbc; 
      border-radius: 10px;
    }
    ::-webkit-scrollbar-thumb:hover {
      background: #8f8f8f; 
    }
 
   #co{
       display: grid; grid-template-columns: repeat(4, 290px); grid-row-gap: 60px; grid-column-gap: 50px; justify-content: center; align-content: center;
   }
   
   @media (max-width: 1000px) {
       h1{
           color: red;
       }

    }
   
   .genre:hover{
    transform:scale(1.1);
    transition-duration: 0.5s;
}
  h1{
        color: black;
        font-size: 25px;
    }
    h3{
        color: black;
        font-size: 20px;
    }
    .cover{
        width: 160px;
        height: 160px;
        object-fit: cover;
    }
    .image{
    position: relative;
    text-align: center;
    color: white;   
    }


.bottom-left {
    position: absolute;
    bottom: 8px;
    left: 30px;
}
.genre{
    object-fit: cover;
    width: 260px;
    height: 260px;
    border-radius: 10px;
    -webkit-box-shadow: 26px 33px 28px 1px rgba(34, 60, 80, 0.14);
    -moz-box-shadow: 26px 33px 28px 1px rgba(34, 60, 80, 0.14);
    box-shadow: 26px 33px 28px 1px rgba(34, 60, 80, 0.14);
}


.music-player{
background: rgba( 255, 255, 255, 0.2 );
box-shadow: 0 8px 32px 0 rgba( 31, 38, 135, 0.37 );
backdrop-filter: blur( 50px );
-webkit-backdrop-filter: blur( 20px );
border-radius: 10px;
border: 1px solid rgba( 255, 255, 255, 0.18 );
    width: 100%;
    height: 180px;
    border-radius: 15px;
    padding: 10px 18px;
    display: flex;
    align-items: center;
}

.info{
    margin-left: 40px;
    width: 100%;
}

.info h3{
    margin-bottom: 10px;
}

.control-bar{
    margin-top: 30px;
}

.control-bar img{
    height: 20px;
    margin-right: 10px;
    cursor: pointer;
}
.cover:hover{
    filter: brightness(80%);
}
        li{
            color: black;
        } 
   
@font-face {
    font-family: 'Visby';
    src: local('Visby Round CF Bold'), local('Visby-Round-CF-Bold'),
        url('../VisbyRoundCF-Bold.woff2') format('woff2'),
        url('../VisbyRoundCF-Bold.woff') format('woff'),
        url('../VisbyRoundCF-Bold.ttf') format('truetype');
    font-weight: 700;
    font-style: normal;
  }
h3 {
    font-family: 'Visby';  
}
h1 {
    font-family: 'Visby';
	vertical-align: middle;
	font-size: 140%;
	line-height: 0.5;
	color: black;
	line-height: 1.5;
	font-weight: 700;
	font-size: 22px;
}

h2 {
    font-family: 'Visby';
	font-size: 18px;
	color: black;
}
.im{
    transition: 1s; 
	margin-top: 50px;
	width: 250px;
	height: 250px;
	margin: 10px auto 20px;
	border-radius: 20px;
	object-fit: cover;
}
 .myDiv {

	        border-radius: 35px;

	        padding: 20px;

	        float: left;

	        width: 290px;

	        background: rgba( 255, 255, 255, 0.2 );

			box-shadow: 0 8px 32px 0 rgba( 31, 38, 135, 0.37 );

			backdrop-filter: blur( 4px );

			-webkit-backdrop-filter: blur( 4px );

			border-top: 1px solid rgba( 31, 38, 135, 0.37 );

			border-left: 10px solid rgba(255, 255, 255, 255. 0.3);

	       

	      }


* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: "Poppins", sans-serif;
}
body {
  background-image: url("bac.jpg");
  background-position: center center;

/* Background image doesn't tile */
background-repeat: no-repeat;

/* Background image is fixed in the viewport so that it doesn't move when
the content's height is greater than the image's height */
background-attachment: fixed;

/* This is what makes the background image rescale based
on the container's size */
background-size: cover;
}
.nav {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  padding: 15px 200px;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
  z-index: 100;
  backdrop-filter: blur(50px);
  -webkit-backdrop-filter: blur(30px)
}
.nav,
.nav .nav-links {
  display: flex;
  align-items: center;
}
.nav {
  justify-content: space-between;
  border-radius: 0px;
}
a {
  color: #fff;
  text-decoration: none;
}
.nav .logo {
  font-size: 22px;
  font-weight: 500;
}
.nav .nav-links {
  column-gap: 20px;
  list-style: none;
}
.nav .nav-links a {
  transition: all 0.2s linear;
}
.nav.openSearch .nav-links a {
  opacity: 0;
  pointer-events: none;
}
.nav .search-icon {
  color: black;
  font-size: 20px;
  cursor: pointer;
}
.nav .search-box {
  position: absolute;
  right: 250px;
  height: 45px;
  max-width: 555px;
  width: 100%;
  opacity: 0;
  pointer-events: none;
  transition: all 0.2s linear;
}
.nav.openSearch .search-box {
  opacity: 1;
  pointer-events: auto;
}
.search-box .search-icon {
  position: absolute;
  left: 15px;
  top: 50%;
  left: 15px;
  color: black;
  transform: translateY(-50%);
}
.search-box input {
  height: 100%;
  width: 100%;
  border: none;
  outline: none;
  border-radius: 6px;
  background-color: #fff;
  padding: 0 15px 0 45px;
}

.nav .navOpenBtn,
.nav .navCloseBtn {
  display: none;
}

/* responsive */
@media screen and (max-width: 1160px) {
    .genre{
        width: 200px;
        height: 200px;
    }
  .nav {
    padding: 15px 100px;
  }
  .nav .search-box {
    right: 150px;
  }
}
@media screen and (max-width: 950px) {
  .nav {
    padding: 15px 50px;
  }
  .nav .search-box {
    right: 100px;
    max-width: 400px;
  }
}
@media screen and (max-width: 768px) {
  .nav .navOpenBtn,
  .nav .navCloseBtn {
    display: block;
  }
  .nav {
    padding: 15px 20px;
  }
  .nav .nav-links {
    position: fixed;
    top: 0;
    left: -100%;
    height: 100%;
    max-width: 280px;
    width: 100%;
    padding-top: 100px;
    row-gap: 30px;
    flex-direction: column;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    backdrop-filter: blur(30px);
    -webkit-backdrop-filter: blur( 30px );
    border-radius: 15px;
    color:  red;
    transition: all 0.4s ease;
    z-index: 100;
  }
  .nav.openNav .nav-links {
    left: 0;
  }
  .nav .navOpenBtn {
    color: black;
    font-size: 20px;
    cursor: pointer;
  }
  .nav .navCloseBtn {
    position: absolute;
    top: 20px;
    right: 20px;
    color: black;
    font-size: 20px;
    cursor: pointer;
  }
  .nav .search-box {
    top: calc(100% + 10px);
    max-width: calc(100% - 20px);
    right: 50%;
    transform: translateX(50%);
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  }
}

@media screen and (max-width: 768px) {
    
    
    #co{
        display: grid; grid-template-columns: repeat(2, 170px); grid-row-gap: 20px; grid-column-gap: 0px; justify-content: center; align-content: center;
    }
    
    .genre{
        height: 150px;
        width: 150px;
    }
    h3{
        
    }
    h1{
        
    }
    
    .container{
        margin-top: 50px;
    }
    .info{
    margin-top: 25px;
    margin-left: 15px;
    

    }
    #ge{
       display: none;
    }
    #waveform0 ::part(wrapper) {
        height: 25px
    }
    #waveform1 ::part(wrapper) {
        height: 25px
    }
    #waveform2 ::part(wrapper) {
        height: 25px
    }
    #waveform3 ::part(wrapper) {
        height: 25px
    }
    #waveform4 ::part(wrapper) {
        height: 25px
    }
    #waveform5 ::part(wrapper) {
        height: 25px
    }
    h1{
        font-size: 15px;
    }
    h3{
        font-size: 10px;
    }
    .music-player{
        height: 100px;
    }
    .cover{
        height: 80px;
        width: 80px;
        border-radius: 5px;
        object-fit: cover;
    }
  .nav .navOpenBtn,
  .nav .navCloseBtn {
    display: block;
  }
  .nav {
    padding: 15px 20px;
  }
  .nav .nav-links {
    position: fixed;
    top: 0;
    left: -100%;
    height: 100%;
    max-width: 280px;
    width: 100%;
    padding-top: 100px;
    row-gap: 30px;
    flex-direction: column;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    backdrop-filter: blur(20px);
    -webkit-backdrop-filter: blur( 20px );
    border-radius: 15px;
    color:  red;
    transition: all 0.4s ease;
    z-index: 100;
  }
  .nav.openNav .nav-links {
    left: 0;
  }
  .nav .navOpenBtn {
    color: black;
    font-size: 20px;
    cursor: pointer;
  }
  .nav .navCloseBtn {
    position: absolute;
    top: 20px;
    right: 20px;
    color: black;
    font-size: 20px;
    cursor: pointer;
  }
  .nav .search-box {
    top: calc(100% + 10px);
    max-width: calc(100% - 20px);
    right: 50%;
    transform: translateX(50%);
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  }
}
.preloader {
	  /*фиксированное позиционирование*/
	  position: fixed;
	  /* координаты положения */
	  left: 0;
	  top: 0;
	  right: 0;
	  bottom: 0;
	  /* фоновый цвет элемента */
	  background: white;
	  /* размещаем блок над всеми элементами на странице (это значение должно быть больше, чем у любого другого позиционированного элемента на странице) */
	  z-index: 1001;
	}
	
	.preloader__row {
	  position: relative;
	  top: 50%;
	  left: 50%;
	  width: 70px;
	  height: 70px;
	  margin-top: -35px;
	  margin-left: -35px;
	  text-align: center;
	  animation: preloader-rotate 2s infinite linear;
	}
	
	.preloader__item {
	  position: absolute;
	  display: inline-block;
	  top: 0;
	  background-color: black;
	  border-radius: 100%;
	  width: 35px;
	  height: 35px;
	  animation: preloader-bounce 2s infinite ease-in-out;
	}
	
	.preloader__item:last-child {
	  top: auto;
	  bottom: 0;
	  animation-delay: -1s;
	}
	
	@keyframes preloader-rotate {
	  100% {
	    transform: rotate(360deg);
	  }
	}
	
	@keyframes preloader-bounce {
	
	  0%,
	  100% {
	    transform: scale(0);
	  }
	
	  50% {
	    transform: scale(1);
	  }
	}
	
	.loaded_hiding .preloader {
	  transition: 0.3s opacity;
	  opacity: 0;
	}
	
	.loaded .preloader {
	  display: none;
	}
.block > img, .block > h1 { display: inline-block; } @media (max-width: 1000px) { .name{ font-size: 20px; overflow: hidden; } .cover{ } } @media (min-width: 1000px) { .name{ font-size: 50px; } }
    .main{
        font-size: 22px;
    }
    .sub{
        font-size: 20px;
    }
    @media screen and (max-width: 770px) {
    
    .cover{
        
    }
    .main{
        font-size: 15px;
    }
    .sub{
        font-size: 10px;
    }
}
   </style>
  </head>
  <body>
    <div class="preloader">
		<div class="preloader__row">
			<div class="preloader__item"></div>
			<div class="preloader__item"></div>
		</div>
	</div>
	<script>
	window.onload = function () {
	    document.body.classList.add('loaded_hiding');
	    window.setTimeout(function () {
	      document.body.classList.add('loaded');
	      document.body.classList.remove('loaded_hiding');
	    }, 500);
	  }
	  function onlyPlayOneIn(container) {
	  container.addEventListener("play", function(event) {
	  audio_elements = container.getElementsByTagName("audio")
	    for(i=0; i < audio_elements.length; i++) {
	      audio_element = audio_elements[i];
	      if (audio_element !== event.target) {
	        audio_element.pause();
	      }
	    }
	  }, true);
	}
	
	document.addEventListener("DOMContentLoaded", function() {
	  onlyPlayOneIn(document.body);
	});
	</script>
    <nav class="nav">
      <i class="uil uil-bars navOpenBtn"></i>
      <a href="index.php" class="logo">

          <h1 style="font-size: 130%;">Waves</h1>
      </a>
      <ul class="nav-links">
          <br>
        <i class="uil uil-times navCloseBtn"></i>
        <li><a href="playlist.php"><h1 style="font-family: "Mona";">Playlists</h1></a></li>
        <?php
        if(empty($_COOKIE["login"])){
            echo '
            <li><a href="authorization.php"><h1>Login</h1></a></li>
            ';
        } else{
            echo '
            <li><a href="logout.php"><h1>Log Out</h1></a></li>
            <li><a href="upload.php"><h1 style="font-family: "Mona";">Upload</h1></a></li>
            <li><a href="addFavorites.php"><h1>Favorites</h1></a></li>
            ';
        }
        ?>
      </ul>
      <i class="uil uil-search search-icon" id="searchIcon" style="visibility: ;"></i>
      <div class="search-box">
        <i class="uil uil-search search-icon"></i>
        <form action="search2.php" method="post" enctype="multipart/form-data" style="height: 50px;">
        <input type="text" name="name" placeholder="Введите название песни или исполнителя" />
        </form>
      </div>
    </nav>
    <div class="container">
    <br> 
    <br>
    <br>
    <br>
    <br>
    <?php
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);
    $conn = new mysqli("localhost", "soniasonec", "spve_if4nShqj5xc", "soniasonec");
    if($conn->connect_error){
        die("Ошибка: " . $conn->connect_error);
    }
    $song = $_GET["song"];
    $sql = "SELECT * FROM `songs` WHERE music like '$song' ORDER BY id DESC LIMIT 1;";
    $ID = 0;
    if($result = $conn->query($sql)){
    $rowsCount = $result->num_rows;
    foreach($result as $row){
    $postName = $row["name"];
    $postAuthor = $row["author"];
    $postImage = $row["image"];
    $postMusic = $row["music"];
    echo "
    <br>  
    <div class='music-player' style=''>
        <img src='http://soniasonec.temp.swtest.ru/images/$postImage.jpg' id='playBtn$ID' class='cover' style='border-radius: 10px;'>
            <div class='info' style='margin-top: 20px;'>
                <a href='http://soniasonec.temp.swtest.ru/song.php?song=$postMusic'><h1 class='main' style='font-weight: 700;'>$postName</h1></a>
                <a href='http://soniasonec.temp.swtest.ru/author.php?auth=$postAuthor'><h3 class='sub' style=''>$postAuthor</h3></a>
                <div id='waveform$ID' name='wav' style='@media screen and (max-width: 768px) { #waveform$ID ::part(wrapper) { height: 25px } }' ></div>
                <div class='control-bar'>
                </div>
            </div>
        <script>
        playBtn$ID = document.getElementById('playBtn$ID');
        var wavesurfer$ID = WaveSurfer.create({
            container: '#waveform$ID',
            height: 40,
            waveColor: '#c3c3c3',
            progressColor: '#2b2b2b',
            barWidth: 2,
            responsive: true,
            hideScrollbar: true,
            barRadius: 10
        });
        wavesurfer$ID.load('http://soniasonec.temp.swtest.ru/music/$postMusic.mp3');
        playBtn$ID.onclick = function(){
            wavesurfer$ID.playPause();
            if(playBtn$ID.src.match('play')){

            }
            else{

            }
        }
        

    if(window.innerWidth < 800){
    let wave$ID = document.getElementById('waveform$ID');
    wave$ID.setAttribute('style', '#waveform$ID ::part(wrapper) { height: 25px }');
    }
    
    
    
    
    </script>
    
        </div>
    
    ";
    $ID++; 
    }
}
    
    ?>
    <?php
    ini_set('display_errors', 1); ini_set('display_startup_errors', 1); error_reporting(E_ALL);
    $sql = "SELECT * FROM `songs` WHERE author like '%$postAuthor%' AND music NOT LIKE '$postMusic' ORDER BY id DESC LIMIT 4;";
    if($result = $conn->query($sql)){
    $rowsCount = $result->num_rows;
    if($rowsCount > 1){
    echo "<br>";
    echo "<h1 style='padding: 10px'>Другие песни этого испольнителя:</h1>";
    foreach($result as $row){
    $postName = $row["name"];
    $postAuthor = $row["author"];
    $postMusic = $row["music"];
    echo "
    <br>
    <a href='http://soniasonec.temp.swtest.ru/song.php?song=$postMusic'>
    <div class='d-flex justify-content-between' >
            <div style = 'padding:10px; border-radius: 10px; backdrop-filter: blur(20px); width: 100%'>
                <div>
                <h1>$postName</h1>
                <h2>$postAuthor</h2>
                </div>
            </div>
        </div>
    </a>
    ";
    
    }
    } else{
    $sql = "SELECT * FROM `songs` WHERE music NOT LIKE '$postMusic' ORDER BY RAND() DESC LIMIT 4;";
    if($result = $conn->query($sql)){
    echo "<br>";
    echo "<h1 style='padding: 10px'>Так же можете послушать:</h1>";
    foreach($result as $row){
    $postName = $row["name"];
    $postAuthor = $row["author"];
    $postMusic = $row["music"];
    echo "
    <br>
    <a href='http://soniasonec.temp.swtest.ru/song.php?song=$postMusic'>
    <div class='d-flex justify-content-between' >
            <div style = 'padding:10px; border-radius: 10px; backdrop-filter: blur(20px); width: 100%'>
                <div>
                <h1>$postName</h1>
                <h2>$postAuthor</h2>
                </div>
            </div>
        </div>
    </a>
    ";
    
    }
        
    }
        
    }
}
    
    ?>
    
    
    <script>
    {
        const formatTime = (seconds) => {
        const minutes = Math.floor(seconds / 60)
        const secondsRemainder = Math.round(seconds) % 60
        const paddedSeconds = `0${secondsRemainder}`.slice(-2)
        return `${minutes}:${paddedSeconds}`
    }
    
      const wave0 = document.querySelector('#time0')
      wavesurfer0.on('timeupdate', (currentTime) => (wave0.textContent = formatTime(currentTime)))
      
    
    }
        
    </script>
    <br>
    </div>
    </div>
        
    </div>
    
        <script>
            if(window.innerWidth < 700){
                document.getElementById('1co').style = 'display: grid; grid-template-columns: repeat(1, 170px); grid-row-gap: 10px; grid-column-gap: 10px; justify-content: center; align-content: center;';
                document.getElementsByClassName('cover').style= 'height: 70px; width: 70px';
                }
            if(window.innerWidth < 1100){
                document.getElementById('co').style = 'display: grid; grid-template-columns: repeat(3, 190px); grid-row-gap: 60px; grid-column-gap: 80px; justify-content: center; align-content: center;';
                }
            if(wavesurfer0.playPause();){
            
                wavesurfer1.playPause();
            }
        </script>
   <script src="vt.js"></script>
  </body>
</html>