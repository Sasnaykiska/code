<?php

//ini_set('display_errors', 1);

//ini_set('display_startup_errors', 1);

//error_reporting(E_ALL);

function get_data()

{

	$conn = new mysqli("localhost", "soniasonec", "spve_if4nShqj5xc", "soniasonec");

	$sql = "SELECT * FROM `songs` ORDER BY id DESC;";

	$res = mysqli_query($conn, $sql);

	$emp = array();

	while ($row = mysqli_fetch_array($res)) {

	$emp[] = [

	

      "id" => $row["id"],

	    "name" => $row["name"],

	    "artist" => $row["author"],

	    "src" => $row["music"],

	    "img" => $row["image"],

	    "color" => $row["imageColor"]

			

		];

	}

	return json_encode($emp);

}

$data = ''.(get_data())."";

?>

<!DOCTYPE html>

<html lang="en">

<head>

  <meta charset="UTF-8">

  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <title>Waves</title>

  <link rel = "icon" href = "logo.png" 

        type = "image/x-icon">

  <link rel="stylesheet" href="/css/st.css">

  <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

  <script src="https://kit.fontawesome.com/6feed9d60e.js" crossorigin="anonymous"></script>

  <style>
  .music-list{
      backdrop-filter: blur(20px);
  }

  background-image{

  opacity: 0.33;

  }

  body{

    background-size: 200%;

    background-position: center;

    backdrop-filter: blur(200px);

    -webkit-backdrop-filter: blur(90px);



  }

  i{

      color: #1E90FF;

  }

  nav{

      display: flex;

      justify-content: space-between;

      margin-bottom: 30px;

    }

    @media (max-width: 1000px) {

      .song-details p{

        text-align: start;

        margin-left: 6%;



      }

    }

    

    @media (min-width: 1000px) {



      .wrapper{

          margin-top: 5%;

      }

    }

    

    i{

        color: white;

    }

    

  </style>

</head>

<body>

  <div class="wrapper">

        <nav>

          <div class="circle">

            <a href="index.php"><i class="fa-solid fa-angle-left"></i></a>

          </div>

          <div class="circle">

            <a href="upload.php"><i class="fa-solid fa-upload"></i></a>

          </div>

        </nav>

    <div class="img-area">

      <img src="" alt="" class="image" id="ima">

    </div>

    <div class="song-details">

      <p class="name"></p>

      <p class="artist"></p>

    </div>

    <div class="progress-area">

      <div class="progress-bar">

        <audio id="main-audio" src=""></audio>

      </div>

      <div class="song-timer">

        <span class="current-time">0:00</span>

        <span class="max-duration">0:00</span>

      </div>

    </div>

    <div class="controls">

      <i id="repeat-plist" class="material-icons" title="Playlist looped">repeat</i>

      <i id="prev" class="material-icons">skip_previous</i>

      <div class="play-pause">

        <i class="material-icons play">play_arrow</i>

      </div>

      <i id="next" class="material-icons">skip_next</i>

      <i id="more-music" class="material-icons">queue_music</i>

    </div>

    <div class="music-list">

      <div class="header">

        <div class="row">

        </div>

        <i id="close" class="material-icons">close</i>

      </div>

      <ul>

      </ul>

    </div>

  </div>

  <script>

      let allMusic = <?php echo $data ?>

  </script>

  <!--<script src="test2.js"></script>-->

  <script src="/js/norm2.js"></script>



</body>

</html>