<?php
$link = $_POST["link"];
$id = $_POST["id"];
$conn = new PDO('mysql:host=localhost;dbname=soniasonec', 'soniasonec', 'spve_if4nShqj5xc');
$sql = $conn->prepare("DELETE FROM `play_songs` WHERE song_id = :id AND playlist_link = :link;");
$sql->execute(array(
        ':id' => $id,
        ':link' => $link 
));