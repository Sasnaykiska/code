import sys
import MySQLdb as mdb
from PIL import Image
image1 = sys.argv[1]
print(image1)
photoID = sys.argv[2]
print(photoID)
image = Image.open(image1)
 
w, h = image.size
rr, gg, bb = 0, 0, 0
 
for x in range(w):
    for y in range(h):
        r, g, b = image.getpixel((x, y))
        rr += r
        gg += g
        bb += b
 
cnt = w * h
a = (rr // cnt, gg // cnt, bb // cnt)
print(a)
b = str(a)


DBNAME = "soniasonec"
DBHOST = "localhost"
DBPASS = "spve_if4nShqj5xc"
DBUSER = "soniasonec"


db = mdb.connect(DBHOST, DBUSER, DBPASS, DBNAME)

cur = db.cursor()

updata = "UPDATE `songs` SET `imageColor` = '"+b+"' WHERE image = '"+photoID+"';"
print(updata)

try: 
  cur.execute(updata)
  db.commit()
  print("suc")

except:
  print("error")

db.close()