    <?php
    if(isset($_POST["upload"])){
    $login = $_POST["login"];
    $password = hash('sha512', $_POST["password"]);
    $conn = new PDO('mysql:host=localhost;dbname=soniasonec', 'soniasonec', 'spve_if4nShqj5xc');
    $stmt = $conn->prepare("SELECT login, password FROM users WHERE login=:login AND password =:password");
    $stmt->execute(['login' => $login, 'password' => $password]); 
    $sql = $stmt->rowCount();
        if($sql > 0){
        setcookie("login", $login, time()+20*24*60*60, "/");
        echo "<meta http-equiv='refresh' content='0;URL=http://soniasonec.temp.swtest.ru/'/>";
        die();
        } 
    }
    ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <link rel = "icon" href = "logo.png" type = "image/x-icon">
	<link rel="icon" href="logo.png" type="image/icon type">
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Waves</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Montserrat+Alternates:wght@800&family=Source+Sans+Pro&display=swap" rel="stylesheet">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css" />
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
   <script src="../js/bg.js" defer></script>
   <style>
      @media screen and (min-width: 1000px) {
      .nav-links{
        margin: auto;
      }
    }
@font-face {
    font-family: 'Visby';
    src: local('Visby Round CF Bold'), local('Visby-Round-CF-Bold'),
        url('VisbyRoundCF-Bold.woff2') format('woff2'),
        url('VisbyRoundCF-Bold.woff') format('woff'),
        url('VisbyRoundCF-Bold.ttf') format('truetype');
    font-weight: 700;
    font-style: normal;
  }
h3 {
    color: black;
    font-family: 'Visby';
}
h1 {
    color: black;
    font-family: 'Visby';
	vertical-align: middle;
	font-size: 130%;
	line-height: 0.5;
	color: black;
	line-height: 1.5;
}

h2 {
    color: black;
    font-family: Lato, Helvetica, sans-serif;
	font-size: 100%;
	color: rgb(254, 254, 254);
}
.im{
    transition: 1s; 
	margin-top: 50px;
	width: 250px;
	height: 250px;
	margin: 10px auto 20px;
	border-radius: 20px;
	object-fit: cover;
}
 .myDiv {

	        border-radius: 35px;

	        padding: 20px;

	        float: left;

	        width: 290px;

	        background: rgba( 255, 255, 255, 0.2 );

			box-shadow: 0 8px 32px 0 rgba( 31, 38, 135, 0.37 );

			backdrop-filter: blur( 4px );

			-webkit-backdrop-filter: blur( 4px );

			border-top: 1px solid rgba( 31, 38, 135, 0.37 );

			border-left: 10px solid rgba(255, 255, 255, 255. 0.3);

	       

	      }



* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: "Poppins", sans-serif;
}


body {
  background-image: url("image.png");
  background-position: center center;

/* Background image doesn't tile */
background-repeat: no-repeat;

/* Background image is fixed in the viewport so that it doesn't move when
the content's height is greater than the image's height */
background-attachment: fixed;

/* This is what makes the background image rescale based
on the container's size */
background-size: cover;
}


.nav {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  padding: 15px 200px;
  backdrop-filter: blur(20px);
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
  z-index: 100;
}
.nav,
.nav .nav-links {
  display: flex;
  align-items: center;
}
.nav {
  justify-content: space-between;
  border-radius: 10px;
}
a {
  color: #fff;
  text-decoration: none;
}
.nav .logo {
  font-size: 22px;
  font-weight: 500;
}
.nav .nav-links {
  column-gap: 20px;
  list-style: none;
}
.nav .nav-links a {
  transition: all 0.2s linear;
}
.nav.openSearch .nav-links a {
  opacity: 0;
  pointer-events: none;
}
.nav .search-icon {
  color: #fff;
  font-size: 20px;
  cursor: pointer;
}
.nav .search-box {
  position: absolute;
  right: 250px;
  height: 45px;
  max-width: 555px;
  width: 100%;
  opacity: 0;
  pointer-events: none;
  transition: all 0.2s linear;
}
.nav.openSearch .search-box {
  opacity: 1;
  pointer-events: auto;
}
.search-box .search-icon {
  position: absolute;
  left: 15px;
  top: 50%;
  left: 15px;
  color: #4a98f7;
  transform: translateY(-50%);
}
.search-box input {
  height: 100%;
  width: 100%;
  border: none;
  outline: none;
  border-radius: 6px;
  background-color: #fff;
  padding: 0 15px 0 45px;
}

.nav .navOpenBtn,
.nav .navCloseBtn {
  display: none;
}

/* responsive */
@media screen and (max-width: 1160px) {
  .nav {
    padding: 15px 100px;
  }
  .nav .search-box {
    right: 150px;
  }
}
@media screen and (max-width: 950px) {
  .nav {
    padding: 15px 50px;
  }
  .nav .search-box {
    right: 100px;
    max-width: 400px;
  }
}
@media screen and (max-width: 768px) {
  .nav .navOpenBtn,
  .nav .navCloseBtn {
    display: block;
  }
  .nav {
    padding: 15px 20px;
  }
  .nav .nav-links {
    position: fixed;
    top: 0;
    left: -100%;
    height: 100%;
    max-width: 280px;
    width: 100%;
    padding-top: 100px;
    row-gap: 30px;
    flex-direction: column;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    backdrop-filter: blur(20px);
    -webkit-backdrop-filter: blur( 20px );
    border-radius: 15px;
    color:  red;
    transition: all 0.4s ease;
    z-index: 100;
  }
  .nav.openNav .nav-links {
    left: 0;
  }
  .nav .navOpenBtn {
    color: #fff;
    font-size: 20px;
    cursor: pointer;
  }
  .nav .navCloseBtn {
    position: absolute;
    top: 20px;
    right: 20px;
    color: #fff;
    font-size: 20px;
    cursor: pointer;
  }
  .nav .search-box {
    top: calc(100% + 10px);
    max-width: calc(100% - 20px);
    right: 50%;
    transform: translateX(50%);
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  }
}
   </style>
  </head>
  <body>
    <nav class="nav">
      <i class="uil uil-bars navOpenBtn"></i>
      <a href="index.php" class="logo"><h1 style="color: black">Waves</h1></a>
      <ul class="nav-links">
        <i class="uil uil-times navCloseBtn"></i>
        <li><a href="playlist.php"><h1 style="font-family: "Mona"; color: black;">Playlists</h1></a></li>
        <?php
        if(empty($_COOKIE["login"])){
            echo '
            <li><a href="authorization.php"><h1>Login</h1></a></li>
            ';
        } else{
            echo '
            <li><a href="logout.php"><h1 style="color: black;">Log Out</h1></a></li>
            <li><a href="upload.php"><h1 style="font-family: "Mona"; color: black">Upload</h1></a></li>
            <li><a href="addFavorites.php"><h1>Favorites</h1></a></li>
            ';
        }
        ?>
      </ul>
      <i class="uil uil-search search-icon" id="searchIcon" style="visibility: ; color: black"></i>
      <div class="search-box" style="color: black;">
        <i class="uil uil-search search-icon" style="color: black;"></i>
        <form action="search2.php" method="post" enctype="multipart/form-data" style="height: 50px;">
        <input type="text" name="name" placeholder="Введите название песни или исполнителя" />
        </form>
      </div>
    </nav>
<div class="container">
    <br>
    <br>
    <br>
    <br>
    <br>
    <form action="au.php" method="post" enctype="multipart/form-data">
    <div style="backdrop-filter: blur(20px); padding: 20px; border-radius: 10px">
    <h1 style="color: black;">Login</h1>
    <input type="text" name="login" class="form-control" placeholder="Введите login">
    <br>
    <h1 style="color:black">Password</h1>
    <input type="text" name="password" class="form-control" placeholder="Введите password">
    <br>
    
<br>
    <input style="font-family: 'Visby'; background-color: black;" type="submit" name="upload" value="Загрузить" class="btn btn-primary">
    <br>
    <br>
    <a href="registration.php"><h1 style="color: black;">Registration</h1></a>
    <?php
    if(isset($_POST["upload"])){
    if($sql < 1){
        echo "<h1 style='color: red'>Неверные данные</h1>";
    }
    }
    ?>
</div>
</form>
<br>
                    </div>
                </div>
            </div>
</div>
</div>
        <br>
  </body>
</html>