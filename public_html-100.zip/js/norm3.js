const wrapper = document.querySelector(".wrapper"),
    musicImg = wrapper.querySelector(".img-area img"),
    musicName = wrapper.querySelector(".song-details .name"),
    musicArtist = wrapper.querySelector(".song-details .artist"),
    playPauseBtn = wrapper.querySelector(".play-pause"),
    prevBtn = wrapper.querySelector("#prev"),
    nextBtn = wrapper.querySelector("#next"),
    mainAudio = wrapper.querySelector("#main-audio"),
    progressArea = wrapper.querySelector(".progress-area"),
    progressBar = progressArea.querySelector(".progress-bar"),
    musicList = wrapper.querySelector(".music-list"),
    moreMusicBtn = wrapper.querySelector("#more-music"),
    closemoreMusic = musicList.querySelector("#close");

let musicIndex = Math.floor((Math.random() * allMusic.length) + 1);
let isMusicPaused = true;

const obj = document.getElementById("ima");

function resizeImage(isPaused = false) {
    if (isPaused) {
        obj.style.height = window.innerWidth < 500 ? "255px" : "350px";
        obj.style.width = window.innerWidth < 500 ? "255px" : "350px";
    } else {
        obj.style.height = window.innerWidth < 500 ? "300px" : "400px";
        obj.style.width = window.innerWidth < 500 ? "300px" : "400px";
    }
}

window.addEventListener("load", () => {
    loadMusic(musicIndex);
    playingSong();
    resizeImage();
});

function loadMusic(indexNumb) {
    const music = allMusic[indexNumb - 1];
    musicName.innerText = music.name;
    musicArtist.innerText = music.artist;
    musicImg.src = `../../images/${music.img}.jpg`;
    mainAudio.src = `../../music/${music.src}.mp3`;
    document.body.style.background = `linear-gradient(rgb${music.color}90%, black)`;

    if (window.innerWidth < 800) {
        document.body.style.backgroundImage = `url(${musicImg.src})`;
    } else {
        document.querySelector('.music-list').style.background = `linear-gradient(rgb${music.color}60%, #1e1e1e)`;
    }
}

function playMusic() {
    wrapper.classList.add("paused");
    playPauseBtn.querySelector("i").innerText = "pause";
    mainAudio.play();
    resizeImage(false); // Увеличение изображения при воспроизведении
}

function pauseMusic() {
    wrapper.classList.remove("paused");
    playPauseBtn.querySelector("i").innerText = "play_arrow";
    mainAudio.pause();
    resizeImage(true); // Уменьшение изображения при паузе
}

function prevMusic() {
    musicIndex = musicIndex > 1 ? musicIndex - 1 : allMusic.length;
    loadMusic(musicIndex);
    playMusic();
    playingSong();
}

function nextMusic() {
    musicIndex = musicIndex < allMusic.length ? musicIndex + 1 : 1;
    loadMusic(musicIndex);
    playMusic();
    playingSong();
}

playPauseBtn.addEventListener("click", () => {
    const isMusicPlay = wrapper.classList.contains("paused");
    isMusicPlay ? pauseMusic() : playMusic();
    playingSong();
});

prevBtn.addEventListener("click", prevMusic);
nextBtn.addEventListener("click", nextMusic);

mainAudio.addEventListener("timeupdate", () => {
    const currentTime = mainAudio.currentTime;
    const duration = mainAudio.duration;
    progressBar.style.width = `${(currentTime / duration) * 100}%`;

    const musicCurrentTime = wrapper.querySelector(".current-time"),
        musicDuration = wrapper.querySelector(".max-duration");

    mainAudio.addEventListener("loadeddata", () => {
        const mainAdDuration = mainAudio.duration;
        const totalMin = Math.floor(mainAdDuration / 60);
        let totalSec = Math.floor(mainAdDuration % 60);
        if (totalSec < 10) totalSec = `0${totalSec}`;
        musicDuration.innerText = `${totalMin}:${totalSec}`;
    });

    const currentMin = Math.floor(currentTime / 60);
    let currentSec = Math.floor(currentTime % 60);
    if (currentSec < 10) currentSec = `0${currentSec}`;
    musicCurrentTime.innerText = `${currentMin}:${currentSec}`;
});

progressArea.addEventListener("click", (e) => {
    const progressWidth = progressArea.clientWidth;
    const clickedOffsetX = e.offsetX;
    mainAudio.currentTime = (clickedOffsetX / progressWidth) * mainAudio.duration;
    playMusic();
    playingSong();
});

const repeatBtn = wrapper.querySelector("#repeat-plist");
repeatBtn.addEventListener("click", () => {
    switch (repeatBtn.innerText) {
        case "repeat":
            repeatBtn.innerText = "repeat_one";
            repeatBtn.setAttribute("title", "Song looped");
            break;
        case "repeat_one":
            repeatBtn.innerText = "shuffle";
            repeatBtn.setAttribute("title", "Playback shuffled");
            break;
        case "shuffle":
            repeatBtn.innerText = "repeat";
            repeatBtn.setAttribute("title", "Playlist looped");
            break;
    }
});

mainAudio.addEventListener("ended", () => {
    switch (repeatBtn.innerText) {
        case "repeat":
            nextMusic();
            break;
        case "repeat_one":
            mainAudio.currentTime = 0;
            loadMusic(musicIndex);
            playMusic();
            break;
        case "shuffle":
            let randIndex;
            do {
                randIndex = Math.floor((Math.random() * allMusic.length) + 1);
            } while (musicIndex === randIndex);
            musicIndex = randIndex;
            loadMusic(musicIndex);
            playMusic();
            playingSong();
            break;
    }
});

moreMusicBtn.addEventListener("click", () => {
    musicList.classList.toggle("show");

    // Прокрутить к текущей песне
    const currentLi = ulTag.querySelector(`li[li-index="${musicIndex}"]`);
    if (currentLi) {
        currentLi.scrollIntoView({
            behavior: 'smooth',  // Плавная прокрутка
            block: 'center'      // Центрировать по вертикали
        });
    }
});

closemoreMusic.addEventListener("click", () => {
    moreMusicBtn.click();
});

const ulTag = wrapper.querySelector("ul");

ulTag.addEventListener('click', (event) => {
    const clickedElement = event.target.closest('li');
    if (clickedElement) {
        const getLiIndex = clickedElement.getAttribute('li-index');
        musicIndex = parseInt(getLiIndex); // Корректно парсим индекс в число
        loadMusic(musicIndex);
        playMusic();
        playingSong();
    }
});

for (let i = 0; i < allMusic.length; i++) {
    const music = allMusic[i];
    const liTag = `<li li-index="${i + 1}">
                    <div class="row" style='display: flex; align-items: center;'>
                    <div style='display: flex; '>
                        <img class="fit-picture" src="http://soniasonec.temp.swtest.ru/images/${music.img}.jpg"/>
                    </div>
                    <div class="mus-list" style="overflow: hidden;">
                    <span>${music.name}</span>
                    <p>${music.artist}</p>
                    </div>
                    </div>
                    <audio preload="none" class="${music.src}" src="../music/${music.src}.mp3"></audio>
                </li>`;
    ulTag.insertAdjacentHTML("beforeend", liTag);
}

function playingSong() {
    const allLiTag = ulTag.querySelectorAll("li");
    allLiTag.forEach(li => li.classList.remove("playing"));
    const currentLi = ulTag.querySelector(`li[li-index="${musicIndex}"]`);
    if (currentLi) {
        currentLi.classList.add("playing");
    }
}