<?php
$login = $_POST["login"];
$id = $_POST["id"];

$conn = new PDO('mysql:host=localhost;dbname=soniasonec', 'soniasonec', 'spve_if4nShqj5xc');
$sql = $conn->prepare("INSERT INTO `fav` (`userLogin`, `songid`) VALUES (:login,:id);");
$sql->execute(array(
        ':login' => $login,
        ':id' => $id
    ));